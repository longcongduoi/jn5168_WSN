'''
Created on May 3, 2012

@author: nxp29781
'''

import SocketServer
import socket
import libJIP
import datetime
import time
import tempfile
import sys
import traceback
import re
import struct
from ctypes import cast, POINTER

from optparse import OptionParser

VAR_PACKING_LIST = { libJIP.E_JIP_VAR_TYPE_INT8       : '>b',
                     libJIP.E_JIP_VAR_TYPE_INT16      : '>h',
                     libJIP.E_JIP_VAR_TYPE_INT32      : '>i',
                     libJIP.E_JIP_VAR_TYPE_INT64      : '>q',
                     libJIP.E_JIP_VAR_TYPE_UINT8      : '>B',
                     libJIP.E_JIP_VAR_TYPE_UINT16     : '>H',
                     libJIP.E_JIP_VAR_TYPE_UINT32     : '>I',
                     libJIP.E_JIP_VAR_TYPE_UINT64     : '>Q',
                     libJIP.E_JIP_VAR_TYPE_FLT        : '>f',
                     libJIP.E_JIP_VAR_TYPE_DBL        : '>d'}

def log(msg):
    print "%s : %s" % (datetime.datetime.now() - startTime, msg)
    sys.stdout.flush()

def integer(value):
    """ Convert a JRTS string to an integer value """
    if value.startswith('x'):
        return int(value[1:], 16)
    else:
        return int(value) 

def unpackMessageInfo(msgInfo):
    addrIndex    = (msgInfo >> 24) & 0x000000FF
    handle       = (msgInfo >> 16) & 0x000000FF
    notifyHandle = (msgInfo >> 8) & 0x000000FF
    
    return (addrIndex, handle, notifyHandle)

def unpackVarInfo(varInfo):
    varIndex = (varInfo >> 24) & 0x000000FF
    varType  = (varInfo >> 16) & 0x000000FF
    varSize  = (varInfo >> 8) & 0x000000FF 

    return (varIndex, varType, varSize)
  
def packValue(var):
    """Pack a value into an integer"""
    
    if var.Data is None:
        return ""
    
    if var.Type in VAR_PACKING_LIST:
        value = struct.pack(VAR_PACKING_LIST[var.Type], var.Data)
    elif (var.Type == libJIP.E_JIP_VAR_TYPE_STR):
        value = var.Data + '\x00'
    elif (var.Type == libJIP.E_JIP_VAR_TYPE_BLOB):
        value = ''.join([chr(x) for x in var.Data])
    elif (var.Type == libJIP.E_JIP_VAR_TYPE_TABLE_BLOB):
        value = '\x00'
    else:
        raise Exception("Unknown type")

    return value.encode('hex').upper()

def unpackValue(value, jipType):
    """ Unpack a hex encoded value """
    
    hexValue = value.decode('hex')
    if jipType in VAR_PACKING_LIST:
        return struct.unpack(VAR_PACKING_LIST[jipType], hexValue)[0]
    elif (jipType == libJIP.E_JIP_VAR_TYPE_STR):
        return struct.unpack('%dsb' % (len(hexValue) - 1), hexValue)[0]
    elif (jipType == libJIP.E_JIP_VAR_TYPE_BLOB):
        return [ord(x) for x in hexValue];



class Network(libJIP.JIP_Context):
    def __init__(self, Coordinator_Address, Gateway_Address4=None, TCP=False):
        libJIP.JIP_Context.__init__(self)
        self.Nodes = {}
        if (Gateway_Address4 == None):
            self.eConnect(Coordinator_Address)
        else:
            self.eConnect4(Gateway_Address4, Coordinator_Address, TCP=TCP)
        
    def eStartMonitor(self, callback):
        print "Starting monitor"
        sys.stdout.flush()
        self.monitor = libJIP.eJIPService_MonitorNetwork(self, callback)
        print self.monitor
        return self.monitor.result
    
    def eStopMonitor(self):
        return self.monitor.stop()
        
    def findVar(self, address, mibNum, varIndex):
        node = libJIP.psJIP_LookupNode(self, address)
        
        if not node:
            log("Node not found")
            return (libJIP.E_JIP_ERROR_FAILED, None, None, None)
        
# There isn't a LookupMibIndex method in the python bindings. For now just iterate till we find the right MIB
        if (mibNum < 255):
            for mib in node:
                if mib.Index == mibNum:
                    break;
                mib = None
        else:
            mib = node.LookupMibId(mibNum)
        
        if not mib:
            log("Mib not found")
            return (libJIP.E_JIP_ERROR_BAD_MIB_INDEX, node, None, None)
        
        print mib
        var = mib.LookupVarIndex(varIndex)
        
        if not var:
            log("Variable not found")
            return (libJIP.E_JIP_ERROR_BAD_VAR_INDEX, node, mib, None)
        
        return (libJIP.E_JIP_OK, node, mib, var)
                
        
    def getNodes(self, deviceIdFilter):
        return libJIP.JIP_Network_iterator(self, deviceIdFilter)

        
class JipDevice():
    
    def __init__(self, handler):
        """ Initialise state information """
        print "JIP Device"
        self.handler = handler
        return
    
    def identify(self):
        """ identify device """
        MacAddr = 0
        DevType = 0
        Fw = 0
        try:
            FwText = libJIP.JIP_Version
        except AttributeError:
            # Not in this version of the Python bindings
            import ctypes
            FwText = ctypes.c_char_p.in_dll(libJIP.libJIP, "JIP_Version").value
            
        FwText = 'GATEWAY_' + FwText
            
        self.write("OKO,%d,%d,%d,%s" % (MacAddr, DevType, Fw, FwText.encode('hex')))

        return (libJIP.E_JIP_OK, None)
    
    def write(self, msg):
        self.handler.write(msg)
    
    def reset(self):
        """ reset device """
        self.addresses = {}
        self.discovered = False
        self.handler.destroyNetwork()
        return (libJIP.E_JIP_OK, None)
        
    def config(self, item, value):
        """ Configure device """
        return (libJIP.E_JIP_OK, None)
    
    def start(self, nodetype):
        """ Start device """
        self.handler.createNetwork()
        self.write("NTU,0,0,0,0,0,0")
        return (libJIP.E_JIP_OK, None)
        
    def addAddress(self, index, addr1, addr2, addr3, addr4, port):
        """ Add remote address """
        self.handler.discoverNetwork()
                
        address = libJIP.sockaddr_in6("::")
        
        address.sin6_addr.in6_u.u6_addr32[0] = socket.htonl(int(addr1))
        address.sin6_addr.in6_u.u6_addr32[1] = socket.htonl(int(addr2))
        address.sin6_addr.in6_u.u6_addr32[2] = socket.htonl(int(addr3))
        address.sin6_addr.in6_u.u6_addr32[3] = socket.htonl(int(addr4))
        
        address.sin6_port = socket.htons(int(port))
        
        self.addresses[int(index)] = address
        
        log("Add address: " + str(address))

        self.write("ADR,0,%s,%s,%s,%s,%s,%s" % (index, addr1, addr2, addr3, addr4, port))
        
        return (libJIP.E_JIP_OK, None)
    
    def remoteGet(self, msgInfo, mibNum, varIndex, firstEntry = "0", entryCount = "1"):
        """ Remote get """
        msgInfo    = integer(msgInfo)
        mibNum     = integer(mibNum)
        varIndex   = integer(varIndex)
        firstEntry = integer(firstEntry)
        entryCount = integer(entryCount)
        
        addrIndex, handle, _ = unpackMessageInfo(msgInfo)
        
        if not addrIndex in self.addresses:
            return (libJIP.E_JIP_ERROR_FAILED, "Address not registered")
        
        address = self.addresses[addrIndex]
        
        log("Remote get: %s, %x, %d" % (self.addresses[addrIndex], mibNum, varIndex))
        
        node = None
                
        try:
            status, node, mib, var = self.handler.network.findVar(address, mibNum, varIndex)
            if (status == libJIP.E_JIP_OK):
                status = var.Get()
    
                log("Get: " + str(status) + "\n" + str(var))
                
                if isinstance(status, libJIP.JIP_Result):
                    status = status.result
                            
            if (status == libJIP.E_JIP_OK):
                if var.Type == libJIP.E_JIP_VAR_TYPE_TABLE_BLOB:
                    if len(var.Data) == 0:
                        self.write('TGR,0,%d,0,%d,%d,0,0,0,%d,%d,' % (handle, mib.Index, var.Index, var.Type, var.Size))
                        
                    for index, entry in var.Data.items():
                        self.write('TGR,0,%d,0,%d,%d,%d,0,0,%d,%d,%s' % (handle, mib.Index, var.Index, index, var.Type, var.Size, ''.join([chr(x) for x in entry]).encode('hex').upper()))

                
                self.write('RGR,%d,%d,0,%d,%d,%d,%d,%s' % (status, handle, mib.Index, var.Index, var.Type, var.Size, packValue(var)))
            else:
                self.write('RGR,%d,%d,0,0,0,0,0,' % (status, handle))

        finally:
            if node:
                node.Unlock()
        
        return (libJIP.E_JIP_OK, None)
        
    def remoteSet(self, msgInfo, mibNum, varInfo, value):
        """ Remote set """
        
        msgInfo = integer(msgInfo)
        mibNum  = integer(mibNum)
        varInfo = integer(varInfo)
        
        addrIndex, handle, _       = unpackMessageInfo(msgInfo)
        varIndex, varType, varSize = unpackVarInfo(varInfo)
        
        if not addrIndex in self.addresses:
            return (libJIP.E_JIP_ERROR_FAILED, "Address not registered")
        
        address = self.addresses[addrIndex]
        
        value = unpackValue(value, varType)
                    
# Python bindings require a long for setting these types, but struct.unpack
# returns an int if the value is small enough
        if varType == libJIP.E_JIP_VAR_TYPE_UINT64 or varType == libJIP.E_JIP_VAR_TYPE_INT64:
            value = long(value)
        
        log("Remote set: %s, %x, %d, %s" % (self.addresses[addrIndex], mibNum, varIndex, str(value)))
        
        node = None
        
        try:
            status, node, mib, var = self.handler.network.findVar(address, mibNum, varIndex)
            
            if (status == libJIP.E_JIP_OK):
                try:
                    status = var.data_set(value)
                except TypeError as e:
                    log("Incorrect type: " + str(e))
                    status = libJIP.E_JIP_ERROR_WRONG_TYPE
    
                log("Set: " + str(status) + "\n" + str(var))
                
                if isinstance(status, libJIP.JIP_Result):
                    status = status.result
            
            if (status == libJIP.E_JIP_OK):
                self.write('RSR,%d,%d,0,%d,%d' % (status, handle, mib.Index, var.Index))
            else:
                self.write('RSR,%d,%d,0,0,0' % (status, handle))

        finally:
            if node:
                node.Unlock()
        
        return (libJIP.E_JIP_OK, None)
    
    def trap(self, msgInfo, mibIndex, varIndex):
        """ Trap a variable on a remote device """
        
        msgInfo  = integer(msgInfo)
        mibIndex = integer(mibIndex)
        varIndex = integer(varIndex)
        
        addrIndex, handle, notifyHandle = unpackMessageInfo(msgInfo)
        
        address = self.addresses[addrIndex]
        
        log("Remote trap: %s, %x, %d" % (self.addresses[addrIndex], mibIndex, varIndex))
        
        node = None
        
        try:
            status, node, mib, var = self.handler.network.findVar(address, mibIndex, varIndex)
            
            if (status == libJIP.E_JIP_OK):
                status = var.Trap(self.trapCallback, notifyHandle).status
    
                log("Trap: " + str(status) + "\n" + str(var))
                
                if isinstance(status, libJIP.JIP_Result):
                    status = status.result
            
            if (status == libJIP.E_JIP_OK):
                self.write('RTR,%d,%d,0,%d,%d' % (status, handle, mib.Index, var.Index))
            else:
                self.write('RTR,%d,%d,0,0,0' % (status, handle))

        finally:
            if node:
                node.Unlock()
        
        return (libJIP.E_JIP_OK, None) 

    def untrap(self, msgInfo, mibIndex, varIndex):
        """ Trap a variable on a remote device """
        
        msgInfo  = integer(msgInfo)
        mibIndex = integer(mibIndex)
        varIndex = integer(varIndex)
        
        addrIndex, handle, notifyHandle = unpackMessageInfo(msgInfo)
        
        address = self.addresses[addrIndex]
        
        log("Remote untrap: %s, %x, %d" % (self.addresses[addrIndex], mibIndex, varIndex))
        
        node = None
        
        try:
            status, node, mib, var = self.handler.network.findVar(address, mibIndex, varIndex)
            
            if (status == libJIP.E_JIP_OK):
                status = var.Untrap(notifyHandle)
    
                log("Untrap: " + str(status) + "\n" + str(var))
                
                if isinstance(status, libJIP.JIP_Result):
                    status = status.result
            
            if (status == libJIP.E_JIP_OK):
                self.write('RTR,%d,%d,0,%d,%d' % (status, handle, mib.Index, var.Index))
            else:
                self.write('RTR,%d,%d,0,0,0' % (status, handle))

        finally:
            if node:
                node.Unlock()
        
        return (libJIP.E_JIP_OK, None) 
    
    def trapCallback(self, var):
        log("Trap notification")
        mib = cast(var.OwnerMib, POINTER(libJIP.JIP_Mib))[0]
        self.write('RTN,0,0,0,%d,%d,%d,%d,%s' % (mib.Index, var.Index, var.Type, var.Size, packValue(var)))
               
        
        
class JipHandler(SocketServer.StreamRequestHandler):
    
    def __init__(self, request, client_address, server):
        self.dev = JipDevice(self)
        SocketServer.StreamRequestHandler.__init__(self, request, client_address, server)
    
    def handle(self):
        self.commands = { "NET" : self.createNetwork,
                  "RESET"       : self.resetNetwork,
                  "DISCOVER"    : self.discoverNetwork,
                  "MONITOR"     : self.startMonitor,
                  "STOPMONITOR" : self.stopMonitor,
                  "TRAP"        : self.trapVar,
                  "UNTRAP"      : self.untrapVar,
                  "SAVEDEFS"    : self.saveDefinitions,
                  "LOADDEFS"    : self.loadDefinitions,
                  "SAVENETWORK" : self.saveNetwork,
                  "LOADNETWORK" : self.loadNetwork,
                  "GETNODES"    : self.getNodes,
                  "NODE"        : self.getNode,
                  
                  "LCT"         : self.getLastCommandTime,
                  
                  "XID"         : self.dev.identify,
                  "RST"         : self.dev.reset,
                  "CFG"         : self.dev.config,
                  "STR"         : self.dev.start,
                  "RAD"         : self.dev.addAddress,
                  "RGT"         : self.dev.remoteGet,
                  "RTG"         : self.dev.remoteGet,
                  "RMS"         : self.dev.remoteSet,
                  "TRP"         : self.dev.trap,
                  "UNT"         : self.dev.untrap,
                  
                  }
        
        try :
            self.network = None
            
            self.startTime = time.time()
            
            log("Connection from {0}".format(self.client_address[0]))
            while (True):
                self.data = self.rfile.readline().strip()
                if (len(self.data) == 0):
                    log("Connection closed")
                    break
                
                self.data = self.data.replace('\\n', '\n')
                tokens = re.split(r'(?<!\\),', self.data)
                command = tokens[0]
                
                args = tokens[1:]
                
#                for token in tokens[1:]:
#                    try:
#                        if token.startswith('x'):
#                            args.append(int(token[1:], 16))
#                        else:
#                            args.append(int(token))
#                    except:
#                        args.append(token)
                
                status = None
                response = None
                
                start = time.time()
                
                try:
                    if (command in self.commands):                        
                        log("Received command: %s(%s)" % (command, ", ".join(map(str, args))))
                        
                        status, response = self.commands[command](*args)
                        
                        if isinstance(status, libJIP.JIP_Result):
                            status = status.result
                    else:
                        log("Unknown command: %s(%s)" % (command, ", ".join(map(str, args))))
                        response = "Bad command"
                except Exception:
                    etype, value, tb = sys.exc_info()
                    traceback.print_exception(etype, value, tb)
                    response = "Exception: " + str(etype)
                end = time.time()
                
                self.lastCommandTime = end - start
                
                log("Response: " + str(response))
                
                self.sendResponse(status, response)
        finally:
            self.destroyNetwork()
    
    def getLastCommandTime(self):
        return (libJIP.E_JIP_OK, "%d" % (self.lastCommandTime * 1000))
    
    def resetNetwork(self):
        self.destroyNetwork()
        self.startTime = time.time()
        self.createNetwork()
        return (libJIP.E_JIP_OK, None)
    
    def createNetwork(self):
        log("Create network")
        self.network = Network(Coordinator_Address, Gateway_Address4, TCP=Gateway_TCP4)
        return (libJIP.E_JIP_OK, Coordinator_Address)
    
    def destroyNetwork(self):
        log("Destroy network")
        if (self.network != None):
            self.network.Destroy()
            self.network = None
        return (libJIP.E_JIP_OK, None)
    
    def discoverNetwork(self):
        log("Discover network")
        status = self.network.eDiscoverNetwork()
        return (status, None)
        
    def trapVar(self, address, mib, var):
        log("Trap var")
        node = libJIP.psJIP_LookupNode(self.network, libJIP.sockaddr_in6(address))
        try:
            mib = node.LookupMibId(int(mib, 16))
            
            var = mib.LookupVarIndex(int(var))
            
            status = var.Trap(self.TrapCallback).status
        finally:
            node.Unlock()
        
        return (status, None)
            
    def untrapVar(self, address, mib, var):
        log("Untrap var")
        node = libJIP.psJIP_LookupNode(self.network, libJIP.sockaddr_in6(address))
        
        try:
            mib = node.LookupMibId(int(mib, 16))
            
            var = mib.LookupVarIndex(int(var))
            
            status = var.Untrap()
        finally:
            node.Unlock()
        
        return (status, None)

    def getNodes(self, deviceIdFilter):
        log("Get nodes")
        response = ""
        nodes = self.network.getNodes(int(deviceIdFilter))
        for node in nodes:
            response = response + "\n" + node.Address + ',%08x' % (node.DeviceId)
        return (libJIP.E_JIP_OK, response)
        
    def getNode(self, address):
        log('Get node')
        node = libJIP.psJIP_LookupNode(self.network, libJIP.sockaddr_in6(address))
        
        response = ""
        
        for mib in node:
            response = response + '\n%d,%08x,%s' % (mib.Index, mib.MibId, mib.Name)
            for var in mib:
                response = response + ',%d,%s,%02x,%d,%02x,%02x' % (var.Index, var.Name, var.Type, var.Size, var.Security, var.AccessType)
        
        node.Unlock()
        return (libJIP.E_JIP_OK, response)

    def saveDefinitions(self):
        tmpfile = tempfile.NamedTemporaryFile(suffix=".xml")
        log("Saving definitions to file: " + tmpfile.name)
        status = self.network.ePersistXMLSaveDefinitions(tmpfile.name)
        lines = tmpfile.file.readlines()
        tmpfile.close()
        lines = ''.join(lines)
        return (status, lines)
        
    def loadDefinitions(self, definitionsXml):
        tmpfile = tempfile.NamedTemporaryFile(suffix=".xml")
        tmpfile.file.write(definitionsXml.replace("\\,", ","))
        tmpfile.file.flush()
        log("Loading definitions from file: " + tmpfile.name)
        status = self.network.ePersistXMLLoadDefinitions(tmpfile.name)
        tmpfile.close()
        return (status, None)
        
    def saveNetwork(self):
        tmpfile = tempfile.NamedTemporaryFile(suffix=".xml")
        log("Saving network to file: " + tmpfile.name)
        status = self.network.ePersistXMLSaveNetwork(tmpfile.name)
        lines = tmpfile.file.readlines()
        tmpfile.close()
        lines = ''.join(lines)
        return (status, lines)
        
    def loadNetwork(self, networkXml):
        tmpfile = tempfile.NamedTemporaryFile(suffix=".xml")
        tmpfile.file.write(networkXml)
        tmpfile.file.flush()
        log("Loading network from file: " + tmpfile.name)
        status = self.network.ePersistXMLLoadNetwork(tmpfile.name)
        tmpfile.close()
        return (status, None)
    
    def startMonitor(self):
        return (self.network.eStartMonitor(self.MonitorCallback), None)
    
    def stopMonitor(self):
        return (self.network.eStopMonitor(), None)
             
    def MonitorCallback(self, Change, Node):
        print "Event: %d" % Change
        if (Change == libJIP.E_JIP_NODE_JOIN):
            log(str(Node) + " joined")
            self.write_async("NODE_JOIN")
                
        elif (Change == libJIP.E_JIP_NODE_LEAVE):
            log(str(Node) + " left")
            self.write_async("NODE_LEAVE")
            
        elif (Change == libJIP.E_JIP_NODE_MOVE):
            log(str(Node) + " moved")
            self.write_async("NODE_MOVE")
        else:
            print "Unknown event"

    def TrapCallback(self, var):
        self.write_async("TRAP," + str(var))
                
    def sendResponse(self, status, response = ""):
        # A status of None is invalid. Return a generic failure code.
        if (status == None):
            status = libJIP.E_JIP_ERROR_FAILED
        
        if (response == None):
            response = ""
        else:
            response = response.strip(",\n")
            
            if (len(response) > 0):
                response = "," + response 
            
        if (status == libJIP.E_JIP_OK):
            self.write("OK%s" % (response))
        else:
            self.write("ERR,%02x%s" % (status, response))
                
    def write(self, msg):
#        header = "S%08d:" % ((time.time() - self.startTime) * 1000)
        packet = msg.replace('\n', '\\n') + "\n"

        self.wfile.write(packet);
        
    def write_async(self, msg):
        self.write(msg)

if __name__ == "__main__":
    parser = OptionParser()
    parser.add_option("-6", "--ipv6", dest="addr",
                  help="coordinator ipv6 address ADDR", metavar="ADDR")
    parser.add_option("-4", "--ipv4", dest="addr4",
                  help="gateway ipv4 address ADDR", metavar="ADDR4")
    parser.add_option("-t", "--tcp", dest="tcp", action="store_true",
                  help="Use TCP to connect to IPv4 gateway", metavar="TCP")
    parser.add_option("-p", "--port", dest="port", default=3294, type="int",
                  help="listen for connections on port PORT", metavar="PORT")

#    parser.add_option("-v", "--verbose", dest="verbose",  action="store_true")

    (options, args) = parser.parse_args()
    
    HOST = "0.0.0.0"
    
    startTime = datetime.datetime.now()

    log("---- JIP Gateway Test Server ----")
    
    if (options.addr == None):
        print "A coordinator address must be specified"
        sys.exit()
    else:
        log("Coordinator addr: " + options.addr)
        Coordinator_Address = options.addr
        
    if (options.addr4 == None):
        log("Native IPv6 connection")
        Gateway_Address4 = None
        Gateway_TCP4 = False
    else:
        Gateway_Address4 = options.addr4
        
        if (options.tcp == True):
            log("TCP/IPv4 Connection via gateway: " + options.addr4)
            Gateway_TCP4 = True
        else:
            log("UDP/IPv4 Connection via gateway: " + options.addr4)
            Gateway_TCP4 = False

    # Create the server, binding to localhost on port 9999
    SocketServer.TCPServer.allow_reuse_address = True
    server = SocketServer.TCPServer((HOST, options.port), JipHandler)

    log("Listening on port %d" % (options.port))

    # Activate the server; this will keep running until you
    # interrupt the program with Ctrl-C
    server.serve_forever()
