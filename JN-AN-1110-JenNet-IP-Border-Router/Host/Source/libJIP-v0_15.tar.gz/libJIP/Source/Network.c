/****************************************************************************
 *
 * MODULE:             libJIP
 *
 * COMPONENT:          Network.c
 *
 * REVISION:           $Revision: 49733 $
 *
 * DATED:              $Date: 2012-11-22 13:22:15 +0000 (Thu, 22 Nov 2012) $
 *
 * AUTHOR:             Matt Redfearn
 *
 ****************************************************************************
 *
 * This software is owned by NXP B.V. and/or its supplier and is protected
 * under applicable copyright laws. All rights are reserved. We grant You,
 * and any third parties, a license to use this software solely and
 * exclusively on NXP products [NXP Microcontrollers such as JN5148, JN5142, JN5139]. 
 * You, and any third parties must reproduce the copyright and warranty notice
 * and any other legend of ownership on each copy or partial copy of the 
 * software.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.

 * Copyright NXP B.V. 2012. All rights reserved
 *
 ***************************************************************************/

#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <string.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <sys/types.h>
#include <netdb.h>
#include <errno.h>

#include <JIP.h>
#include <JIP_Private.h>
#include <JIP_Packets.h>
#include <Network.h>
#include <Trace.h>
#include <Threads.h>

#define DBG_FUNCTION_CALLS 0
#define DBG_NETWORK 0


/** If this is defined, then the source port of UDP datagrams from libJIP will be
 *  bound to JIP_DEFAULT_PORT.
 *  This has the advantage that any registered traps will make it to this process
 *  if it has been restarted.
 */
//#define FIXED_SOURCE_PORT


void *pvSocketListenerThread(void *psThreadInfoVoid);
void *pvTrapHandlerThread(void *psThreadInfoVoid);

tsJIPAddress   Network_MAC_to_IPv6(tsNetworkContext *psNetworkContext, uint64_t u64MAC_Address)
{
    tsJIPAddress sJIPAddress;

    DBG_vPrintf(DBG_FUNCTION_CALLS, "%s\n", __FUNCTION__);
    
    memset (&sJIPAddress, 0, sizeof(struct sockaddr_in6));
    sJIPAddress.sin6_family  = AF_INET6;
    sJIPAddress.sin6_port    = htons(JIP_DEFAULT_PORT);
    
    u64MAC_Address = htobe64(u64MAC_Address);
    
    memcpy(&sJIPAddress.sin6_addr.s6_addr[0], &psNetworkContext->u64IPv6Prefix, sizeof(uint64_t));
    memcpy(&sJIPAddress.sin6_addr.s6_addr[8], &u64MAC_Address, sizeof(uint64_t));
    
    DBG_vPrintf_IPv6Address(DBG_NETWORK, sJIPAddress.sin6_addr);
    
    return sJIPAddress;
}


teNetworkStatus Network_Init(tsNetworkContext *psNetworkContext)
{
    DBG_vPrintf(DBG_FUNCTION_CALLS, "%s\n", __FUNCTION__);
    psNetworkContext->iListenSocket = -1;
    psNetworkContext->iConnectSocket = -1;

    psNetworkContext->eProtocol = E_NETWORK_PROTO_UNKNOWN;
#ifdef LOCK_NETWORK
    /* Create the mutext for the network context */
    if (eLockCreate(&psNetworkContext->sNetworkLock) != E_LOCK_OK)
    {
        DBG_vPrintf(DBG_NETWORK, "Failed to create lock\n");
        return E_NETWORK_ERROR_FAILED;
    }
#endif /* LOCK_NETWORK */

    /* Initialise number of trap threads */
    psNetworkContext->u32NumTrapThreads = 0;
    
    return E_NETWORK_OK;
}


teNetworkStatus Network_Destroy(tsNetworkContext *psNetworkContext)
{  
    eThreadStop(&psNetworkContext->sConnectSocketListener);
    eQueueDestroy(&psNetworkContext->sConnectSocketQueue);
 
    while (u32AtomicGet(&psNetworkContext->u32NumTrapThreads) > 0)
    {
        /* Yield to any trap threads so that they can clean themselves up. */
        eThreadYield();
    }
    
    return E_NETWORK_OK;
}


teNetworkStatus Network_Listen(tsNetworkContext *psNetworkContext, const char *pcAddress, int iPort)
{
    DBG_vPrintf(DBG_FUNCTION_CALLS, "%s\n", __FUNCTION__);

    struct addrinfo hints, *res;
    int s;
    
    // first, load up address structs with getaddrinfo():

    memset(&hints, 0, sizeof hints);
    hints.ai_family = AF_INET6;
    hints.ai_socktype = SOCK_DGRAM;
    hints.ai_flags = AI_PASSIVE;     // fill in my IP for me
    hints.ai_protocol = 0;          /* Any protocol */
    hints.ai_canonname = NULL;
    hints.ai_addr = NULL;
    hints.ai_next = NULL;
           
    s = getaddrinfo(NULL, STRING(JIP_DEFAULT_PORT), &hints, &res);
    if (s != 0) {
        fprintf(stderr, "getaddrinfo: %s\n", gai_strerror(s));
        return E_NETWORK_ERROR_FAILED;
    }

    psNetworkContext->iListenSocket = socket(res->ai_family, res->ai_socktype, res->ai_protocol);
    
    bind(psNetworkContext->iListenSocket, res->ai_addr, sizeof(struct sockaddr_in6));
    
    psNetworkContext->eProtocol = E_NETWORK_PROTO_IPV6;
    psNetworkContext->eLink = E_NETWORK_LINK_UDP;
    
    freeaddrinfo(res);
    
    return E_JIP_OK;
}


teNetworkStatus Network_Connect(tsNetworkContext *psNetworkContext, const char *pcAddress, int iPort)
{
    DBG_vPrintf(DBG_FUNCTION_CALLS, "%s\n", __FUNCTION__);
    
    struct addrinfo hints, *res;
    int s;
    struct in6_addr sDest;
    
    // first, load up address structs with getaddrinfo():

    DBG_vPrintf(DBG_NETWORK, "Connecting to %s\n", pcAddress);
    
    memset(&hints, 0, sizeof (hints));
    hints.ai_family = AF_INET6;
    hints.ai_socktype = SOCK_DGRAM;
    hints.ai_flags = AI_PASSIVE;     // fill in my IP for me
    hints.ai_protocol = 0;          /* Any protocol */
    hints.ai_canonname = NULL;
    hints.ai_addr = NULL;
    hints.ai_next = NULL;
           
    s = getaddrinfo(NULL, STRING(JIP_DEFAULT_PORT), &hints, &res);
    if (s != 0) {
        fprintf(stderr, "getaddrinfo: %s\n", gai_strerror(s));
        return E_NETWORK_ERROR_FAILED;
    }

    psNetworkContext->iConnectSocket = socket(res->ai_family, res->ai_socktype, res->ai_protocol);
    
    if (psNetworkContext->iConnectSocket < 0)
    {
        perror("Could not create socket");
        return E_NETWORK_ERROR_FAILED;
    }
    
#ifdef FIXED_SOURCE_PORT
    /* Bind to the local address, port JIP_DEFAULT_PORT */
    if (bind(psNetworkContext->iConnectSocket, res->ai_addr, res->ai_addrlen) < 0)
    {
        perror("Error binding socket");
        return E_NETWORK_ERROR_FAILED;
    }
#endif /* FIXED_SOURCE_PORT */
    
    freeaddrinfo(res);

    s = inet_pton(AF_INET6, pcAddress, &sDest);
    if (s <= 0)
    {
        if (s == 0)
        {
            fprintf(stderr, "Unknown host: %s\n", pcAddress);
            return E_NETWORK_ERROR_FAILED;
        }
        else if (s < 0)
        {
            perror("inet_pton failed");
            return E_NETWORK_ERROR_FAILED;
        }
    }
    
    memcpy(&psNetworkContext->u64IPv6Prefix, &sDest, sizeof(uint64_t));
   
    memset (&psNetworkContext->sBorder_Router_IPv6_Address, 0, sizeof(struct sockaddr_in6));
    psNetworkContext->sBorder_Router_IPv6_Address.sin6_family  = AF_INET6;
    psNetworkContext->sBorder_Router_IPv6_Address.sin6_port    = htons(iPort);
    psNetworkContext->sBorder_Router_IPv6_Address.sin6_addr    = sDest;

    DBG_vPrintf_IPv6Address(DBG_NETWORK, psNetworkContext->sBorder_Router_IPv6_Address.sin6_addr);

    psNetworkContext->eProtocol = E_NETWORK_PROTO_IPV6;
    psNetworkContext->eLink = E_NETWORK_LINK_UDP;
    
    /* Set up socket listener thread and queue */
    if (eQueueCreate(&psNetworkContext->sConnectSocketQueue, 3) != E_QUEUE_OK)
    {
        DBG_vPrintf(DBG_NETWORK, "Failed to set up connect socket queue\n");
        return E_NETWORK_ERROR_FAILED;
    }
    
    psNetworkContext->sConnectSocketListener.pvThreadData = psNetworkContext;

    if (eThreadStart(pvSocketListenerThread, &psNetworkContext->sConnectSocketListener, E_THREAD_JOINABLE) != E_THREAD_OK)
    {
        DBG_vPrintf(DBG_NETWORK, "Failed to start connect socket listener thread\n");
        return E_NETWORK_ERROR_FAILED;
    }

    DBG_vPrintf(DBG_NETWORK, "Connect socket set up ok\n");

    return E_NETWORK_OK;
}



teNetworkStatus Network_Connect4(tsNetworkContext *psNetworkContext, const char *pcIPv4Address, const char *pcIPv6Address, int iPort, int iTCP)
{
    DBG_vPrintf(DBG_FUNCTION_CALLS, "%s\n", __FUNCTION__);
    
    struct addrinfo hints, *res;
    int s;
    struct in6_addr sDest;
    struct in_addr  sIPv4Gateway;
    
    // first, load up address structs with getaddrinfo():

    DBG_vPrintf(DBG_NETWORK, "Connecting to %s (via %s)\n", pcIPv6Address, pcIPv4Address);
    
    memset(&hints, 0, sizeof (hints));
    hints.ai_family = AF_INET;
    if (iTCP == 0)
    {
        hints.ai_socktype = SOCK_DGRAM;
    }
    else
    {
        hints.ai_socktype = SOCK_STREAM;
    }
    hints.ai_flags = AI_PASSIVE;     // fill in my IP for me
    hints.ai_protocol = 0;          /* Any protocol */
    hints.ai_canonname = NULL;
    hints.ai_addr = NULL;
    hints.ai_next = NULL;
           
    s = getaddrinfo(NULL, STRING(JIP_DEFAULT_PORT), &hints, &res);
    if (s != 0) {
        fprintf(stderr, "getaddrinfo: %s\n", gai_strerror(s));
        return E_NETWORK_ERROR_FAILED;
    }

    psNetworkContext->iConnectSocket = socket(res->ai_family, res->ai_socktype, res->ai_protocol);
    
    if (psNetworkContext->iConnectSocket < 0)
    {
        perror("Could not create socket");
        return E_NETWORK_ERROR_FAILED;
    }
    
#ifdef FIXED_SOURCE_PORT
    /* Bind to the local address, port JIP_DEFAULT_PORT */
    if (bind(psNetworkContext->iConnectSocket, res->ai_addr, res->ai_addrlen) < 0)
    {
        perror("Error binding socket");
        return E_NETWORK_ERROR_FAILED;
    }
#endif /* FIXED_SOURCE_PORT */
    
    freeaddrinfo(res);

    s = inet_pton(AF_INET6, pcIPv6Address, &sDest);
    if (s <= 0)
    {
        if (s == 0)
        {
            fprintf(stderr, "Unknown host: %s\n", pcIPv6Address);
            return E_NETWORK_ERROR_FAILED;
        }
        else if (s < 0)
        {
            perror("inet_pton failed");
            return E_NETWORK_ERROR_FAILED;
        }
    }
    
    s = inet_pton(AF_INET, pcIPv4Address, &sIPv4Gateway);
    if (s <= 0)
    {
        if (s == 0)
        {
            fprintf(stderr, "Unknown host: %s\n", pcIPv4Address);
            return E_NETWORK_ERROR_FAILED;
        }
        else if (s < 0)
        {
            perror("inet_pton failed");
            return E_NETWORK_ERROR_FAILED;
        }
    }
    
    memcpy(&psNetworkContext->u64IPv6Prefix, &sDest, sizeof(uint64_t));

    memset (&psNetworkContext->sBorder_Router_IPv6_Address, 0, sizeof(struct sockaddr_in6));
    psNetworkContext->sBorder_Router_IPv6_Address.sin6_family  = AF_INET6;
    psNetworkContext->sBorder_Router_IPv6_Address.sin6_port    = htons(iPort);
    psNetworkContext->sBorder_Router_IPv6_Address.sin6_addr    = sDest;

    DBG_vPrintf_IPv6Address(DBG_NETWORK, psNetworkContext->sBorder_Router_IPv6_Address.sin6_addr);

    //sIPv4Gateway
    memset (&psNetworkContext->sGateway_IPv4_Address, 0, sizeof(struct sockaddr_in));
    psNetworkContext->sGateway_IPv4_Address.sin_family  = AF_INET;
    psNetworkContext->sGateway_IPv4_Address.sin_port    = htons(iPort);
    psNetworkContext->sGateway_IPv4_Address.sin_addr    = sIPv4Gateway;

    psNetworkContext->eProtocol = E_NETWORK_PROTO_IPV4;
    
    if (iTCP)
    {
        psNetworkContext->eLink = E_NETWORK_LINK_TCP;
        
        if (connect(psNetworkContext->iConnectSocket, (struct sockaddr*)&psNetworkContext->sGateway_IPv4_Address, sizeof(struct sockaddr_in)) != 0)
        {
            perror("Connect");
            DBG_vPrintf(DBG_NETWORK, "Could not connect to gateway\n");
            return E_NETWORK_ERROR_FAILED;
        }
    }
    else
    {
        psNetworkContext->eLink = E_NETWORK_LINK_UDP;
    }
    
    if (eQueueCreate(&psNetworkContext->sConnectSocketQueue, 3) != E_QUEUE_OK)
    {
        DBG_vPrintf(DBG_NETWORK, "Failed to set up connect socket queue\n");
        return E_NETWORK_ERROR_FAILED;
    }
    
    psNetworkContext->sConnectSocketListener.pvThreadData = psNetworkContext;

    if (eThreadStart(pvSocketListenerThread, &psNetworkContext->sConnectSocketListener, E_THREAD_JOINABLE) != E_THREAD_OK)
    {
        DBG_vPrintf(DBG_NETWORK, "Failed to start connect socket listener thread\n");
        return E_NETWORK_ERROR_FAILED;
    }

    DBG_vPrintf(DBG_NETWORK, "Connect socket set up ok\n");

    return E_NETWORK_OK;
}


teNetworkStatus Network_Listen4(tsNetworkContext *psNetworkContext, const char *pcAddress, int iPort, int iTCP)
{
    DBG_vPrintf(DBG_FUNCTION_CALLS, "%s\n", __FUNCTION__);

    struct addrinfo hints, *res;
    int s;
    
    // first, load up address structs with getaddrinfo():

    memset(&hints, 0, sizeof hints);
    hints.ai_family = AF_INET;
    if (iTCP == 0)
    {
        hints.ai_socktype = SOCK_DGRAM;
    }
    else
    {
        hints.ai_socktype = SOCK_STREAM;
    }
    hints.ai_flags = AI_PASSIVE;     // fill in my IP for me
    hints.ai_protocol = 0;          /* Any protocol */
    hints.ai_canonname = NULL;
    hints.ai_addr = NULL;
    hints.ai_next = NULL;
           
    s = getaddrinfo(NULL, STRING(JIP_DEFAULT_PORT), &hints, &res);
    if (s != 0) {
        fprintf(stderr, "getaddrinfo: %s\n", gai_strerror(s));
        return E_NETWORK_ERROR_FAILED;
    }

    psNetworkContext->iListenSocket = socket(res->ai_family, res->ai_socktype, res->ai_protocol);
    
    bind(psNetworkContext->iListenSocket, res->ai_addr, sizeof(struct sockaddr_in));
    
    psNetworkContext->eProtocol = E_NETWORK_PROTO_IPV4;
    
    if (iTCP)
    {
        psNetworkContext->eLink = E_NETWORK_LINK_TCP;
    }
    else
    {
        psNetworkContext->eLink = E_NETWORK_LINK_UDP;
    }
    
    freeaddrinfo(res);
    
    return E_JIP_OK;
}


teNetworkStatus Network_Send(tsNetworkContext *psNetworkContext, tsJIPAddress *psAddress, const char *pcData, int iDataLength)
{
    ssize_t iBytesSent;
    
    DBG_vPrintf(DBG_FUNCTION_CALLS, "%s\n", __FUNCTION__);
    
    DBG_vPrintf_IPv6Address(DBG_NETWORK, psAddress->sin6_addr);
    
    DBG_vPrintf(DBG_NETWORK, "Data length: %d, %p\n", iDataLength, pcData);
    
    if (psNetworkContext->eProtocol == E_NETWORK_PROTO_IPV6)
    {
        DBG_vPrintf(DBG_NETWORK, "Sending direct IPv6 packet\n");
        iBytesSent = sendto(psNetworkContext->iConnectSocket, pcData, iDataLength, 0, 
                        (struct sockaddr*)psAddress, sizeof(struct sockaddr_in6));
    }
    else if (psNetworkContext->eProtocol == E_NETWORK_PROTO_IPV4)
    {
        const uint32_t u32HeaderSize = sizeof(uint8_t) + sizeof(uint16_t) + sizeof(struct in6_addr);
        DBG_vPrintf(DBG_NETWORK, "Sending IPv6 in IPv4 packet\n");
        char *NewPacket = alloca(iDataLength + u32HeaderSize);
        uint16_t u16Length;
        
        u16Length = htons(iDataLength + sizeof(struct in6_addr));

        NewPacket[0] = 1;       /* JIPv4 version */
        memcpy(&NewPacket[1], &u16Length, sizeof(uint16_t));
        memcpy(&NewPacket[3], &psAddress->sin6_addr, sizeof(struct in6_addr));
        memcpy(&NewPacket[u32HeaderSize], pcData, iDataLength);
        
        if (psNetworkContext->eLink == E_NETWORK_LINK_UDP)
        {
            iBytesSent = sendto(psNetworkContext->iConnectSocket, NewPacket, u32HeaderSize + iDataLength, 0, 
                (struct sockaddr*)&psNetworkContext->sGateway_IPv4_Address, sizeof(struct sockaddr_in));
        }
        else if (psNetworkContext->eLink == E_NETWORK_LINK_TCP)
        {
            iBytesSent = send(psNetworkContext->iConnectSocket, NewPacket, u32HeaderSize + iDataLength, 0);
        }
        else
        {
            DBG_vPrintf(DBG_NETWORK, "Unknown Link layer\n");
            return E_NETWORK_ERROR_FAILED;
        }
        DBG_vPrintf(DBG_NETWORK, "Sent %d bytes (of %d)\n", iBytesSent, iDataLength);
        iBytesSent -= u32HeaderSize;
    }
    else
    {
        DBG_vPrintf(DBG_NETWORK, "Unknown protocol\n");
        return E_NETWORK_ERROR_FAILED;
    }
    
    if (iBytesSent != iDataLength)
    {
        perror("Failed to send");
        return E_NETWORK_ERROR_FAILED;
    }
    return E_NETWORK_OK;
}

typedef struct
{
    ssize_t             iBytesRecieved;
    struct sockaddr_in6 sRecv_addr;
#define PACKET_BUFFER_SIZE 1024
    char                acBuffer[PACKET_BUFFER_SIZE];
} tsReceivedPacket;


/** Structure of data passed to a trap handler thread */
typedef struct
{
    tsNetworkContext *psNetworkContext;     /**< Pointer to the network context */
    tsReceivedPacket *psReceivedPacket;     /**< Pointer to the packet that has been received */
} tsTrapHandlerTheadInfo;


void *pvSocketListenerThread(void *psThreadInfoVoid)
{
    tsThread *psThreadInfo = (tsThread *)psThreadInfoVoid;
    tsNetworkContext *psNetworkContext = (tsNetworkContext *)psThreadInfo->pvThreadData;

    DBG_vPrintf(DBG_FUNCTION_CALLS, "%s\n", __FUNCTION__);

    psThreadInfo->eState = E_THREAD_RUNNING;
    
    while (psThreadInfo->eState == E_THREAD_RUNNING)
    {        
        unsigned int AddressSize = sizeof(struct sockaddr_in6);
        tsReceivedPacket *psReceivedPacket = malloc(sizeof(tsReceivedPacket));
        
        if (!psReceivedPacket)
        {
            printf("Could not malloc buffer to receive data\n");
            sleep(1);
            continue;
        }
        
        DBG_vPrintf(DBG_NETWORK, "Ready to get packet\n");
        
        if (psNetworkContext->eLink == E_NETWORK_LINK_TCP)
        {
            psReceivedPacket->iBytesRecieved = recv(psNetworkContext->iConnectSocket, &psReceivedPacket->acBuffer, 
                                                    PACKET_BUFFER_SIZE, 0);
            
            if (psReceivedPacket->iBytesRecieved < 0)
            {
                perror("recv");
            }
            else if (psReceivedPacket->iBytesRecieved == 0)
            {
                printf("Client disconnected\n");
                close(psNetworkContext->iConnectSocket);
                break;
            }
        }
        else if (psNetworkContext->eLink == E_NETWORK_LINK_UDP)
        {
            DBG_vPrintf(DBG_NETWORK, "recv()\n");
            psReceivedPacket->iBytesRecieved = recvfrom(psNetworkContext->iConnectSocket, &psReceivedPacket->acBuffer, 
                                                    PACKET_BUFFER_SIZE, 0,
                                                    (struct sockaddr*)&psReceivedPacket->sRecv_addr, &AddressSize);
            DBG_vPrintf(DBG_NETWORK, "Got %d bytes\n", psReceivedPacket->iBytesRecieved);
        }
        else
        {
            DBG_vPrintf(DBG_NETWORK, "Unknown link layer\n");
        }
        
        if (psReceivedPacket->iBytesRecieved > 0)
        {
            if (psNetworkContext->eProtocol == E_NETWORK_PROTO_IPV4)
            {
                const uint32_t u32HeaderSize = sizeof(uint8_t) + sizeof(uint16_t) + sizeof(struct in6_addr);
                psReceivedPacket->iBytesRecieved -= u32HeaderSize;
                
                memset (&psReceivedPacket->sRecv_addr, 0, sizeof(struct sockaddr_in6));
                psReceivedPacket->sRecv_addr.sin6_family  = AF_INET6;
                psReceivedPacket->sRecv_addr.sin6_port    = htons(JIP_DEFAULT_PORT);
                
                memcpy(&psReceivedPacket->sRecv_addr.sin6_addr, &psReceivedPacket->acBuffer[sizeof(uint8_t) + sizeof(uint16_t)], sizeof(struct in6_addr));
                memmove(&psReceivedPacket->acBuffer[0], &psReceivedPacket->acBuffer[u32HeaderSize], psReceivedPacket->iBytesRecieved);
            }
            tsJIP_MsgHeader *psReceiveHeader;
            
            DBG_vPrintf(DBG_NETWORK, "%s: Packet from node: ", __FUNCTION__);
            DBG_vPrintf_IPv6Address(DBG_NETWORK, psReceivedPacket->sRecv_addr.sin6_addr);
            
            psReceiveHeader = (tsJIP_MsgHeader *)psReceivedPacket->acBuffer; 
            
            if (psReceiveHeader->u8Version != JIP_VERSION)
            {
                /* Check version */
                DBG_vPrintf(DBG_NETWORK, "Version mismatch!\n");
                free(psReceivedPacket);
                continue;
            }
            
            /* Here we check if this is an ad-hoc packet, that we should pass up up for handling,
             * or one we miy have been expecting as part of a challenge-response */            
            switch (psReceiveHeader->eCommand)
            {
                case (E_JIP_COMMAND_TRAP_NOTIFY):
                    {
                        tsThread               *psTrapHandlerThread;
                        tsTrapHandlerTheadInfo *psTrapHandlerTheadInfo;
                        
                        psTrapHandlerThread = malloc(sizeof(tsThread));
                        
                        if (psTrapHandlerThread == NULL)
                        {
                            DBG_vPrintf(DBG_NETWORK, "Could not allocate space for incoming trap\n");
                            free(psReceivedPacket);
                        }
                        else
                        {
                            psTrapHandlerTheadInfo = malloc(sizeof(tsTrapHandlerTheadInfo));
                            
                            if (psTrapHandlerTheadInfo == NULL)
                            {
                                DBG_vPrintf(DBG_NETWORK, "Could not allocate space for incoming trap\n");
                                free(psTrapHandlerThread);
                                free(psReceivedPacket);
                            }
                            else
                            {
                                psTrapHandlerTheadInfo->psNetworkContext = psNetworkContext;
                                psTrapHandlerTheadInfo->psReceivedPacket = psReceivedPacket;
                                psTrapHandlerThread->pvThreadData = psTrapHandlerTheadInfo;

                                if (eThreadStart(pvTrapHandlerThread, psTrapHandlerThread, E_THREAD_DETACHED) != E_THREAD_OK)
                                {
                                    DBG_vPrintf(DBG_NETWORK, "Failed to start trap handler thread\n");

                                    free(psTrapHandlerTheadInfo);
                                    free(psTrapHandlerThread);
                                    free(psReceivedPacket);
                                }
                                else
                                {
                                    /* Increment number of running threads */
                                    u32AtomicAdd(&psNetworkContext->u32NumTrapThreads, 1);
                                }
                            }
                        }
                    }
                    break;
                
                default:
                    if (eQueueQueue(&psNetworkContext->sConnectSocketQueue, psReceivedPacket) != E_QUEUE_OK)
                    {
                        DBG_vPrintf(DBG_NETWORK, "Failed to equeue response packet.\n");
                        free(psReceivedPacket);
                    }
                    else
                    {
                        DBG_vPrintf(DBG_NETWORK, "Response enqueued.\n");
                    }
                    break;
            }
        }
        else
        {
            DBG_vPrintf(DBG_NETWORK, "Error during recv %d: %s.\n",  psReceivedPacket->iBytesRecieved, psReceivedPacket->iBytesRecieved == -1 ? strerror(errno) : "socket closed");
            free(psReceivedPacket);
        }
    }
    
    /* Return from thread clearing resources */
    eThreadFinish(psThreadInfo);
    return NULL;
}


void *pvTrapHandlerThread(void *psThreadInfoVoid)
{
    tsThread *psThreadInfo = (tsThread *)psThreadInfoVoid;
    tsTrapHandlerTheadInfo *psTrapHandlerTheadInfo = (tsTrapHandlerTheadInfo *)psThreadInfo->pvThreadData;
    tsNetworkContext *psNetworkContext = psTrapHandlerTheadInfo->psNetworkContext;
    tsJIP_Context *psJIP_Context = psNetworkContext->psJIP_Context;
    tsReceivedPacket *psReceivedPacket = psTrapHandlerTheadInfo->psReceivedPacket;
    //PRIVATE_CONTEXT(psJIP_Context);
    
    DBG_vPrintf(DBG_FUNCTION_CALLS, "%s\n", __FUNCTION__);

    DBG_vPrintf(DBG_NETWORK, "%s Trap from ", __FUNCTION__);
    DBG_vPrintf_IPv6Address(DBG_NETWORK, psReceivedPacket->sRecv_addr.sin6_addr);
    
    /* Call handler, in this threads context. */
    eJIP_TrapEvent(psJIP_Context, &psReceivedPacket->sRecv_addr, psReceivedPacket->acBuffer);
    
    DBG_vPrintf(DBG_NETWORK, "%s Trap handled ", __FUNCTION__);
    DBG_vPrintf_IPv6Address(DBG_NETWORK, psReceivedPacket->sRecv_addr.sin6_addr);
    
    /* Free up storage and exit this thread */
    free(psReceivedPacket);
    free(psTrapHandlerTheadInfo);
    free(psThreadInfo->pvPriv);
    free(psThreadInfo);
    
    DBG_vPrintf(DBG_NETWORK, "Trap handler thread exit\n");
    
    /* Decrement number of running threads */
    u32AtomicAdd(&psNetworkContext->u32NumTrapThreads, -1);
    return NULL;    
}


teNetworkStatus Network_Recieve(tsNetworkContext *psNetworkContext, tsJIPAddress *psAddress, char *pcData, unsigned int *iDataLength)
{
    tsReceivedPacket *psReceivedPacket;
    
    DBG_vPrintf(DBG_FUNCTION_CALLS, "%s\n", __FUNCTION__);

    
    if (eQueueDequeueTimed(&psNetworkContext->sConnectSocketQueue, 500, (void **)&psReceivedPacket) != E_QUEUE_OK)
    {
        DBG_vPrintf(DBG_NETWORK, "Packet not received\n");
        return E_NETWORK_ERROR_TIMEOUT;
    }
    else
    {
        const char acDefaultAddress[16] = {0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0};
        if (memcmp(acDefaultAddress, &psAddress->sin6_addr, sizeof(struct in6_addr)) != 0)
        {
            if (memcmp(&psAddress->sin6_addr, &psReceivedPacket->sRecv_addr.sin6_addr, sizeof(struct in6_addr)) != 0)
            {
                DBG_vPrintf(DBG_NETWORK, "  Packet from wrong source, expected: ");
                
                DBG_vPrintf_IPv6Address(DBG_NETWORK, psAddress->sin6_addr);
                
                DBG_vPrintf(DBG_NETWORK, "  got: ");
                DBG_vPrintf_IPv6Address(DBG_NETWORK, psReceivedPacket->sRecv_addr.sin6_addr);
                
                /* Not from the right place */
                return E_NETWORK_ERROR_FAILED;
            }
        }
        else
        {
            /* Change the address to the real one */
            memcpy(&psAddress->sin6_addr, &psReceivedPacket->sRecv_addr.sin6_addr, sizeof(struct in6_addr));
            memcpy(&psNetworkContext->sBorder_Router_IPv6_Address.sin6_addr, &psReceivedPacket->sRecv_addr.sin6_addr, sizeof(struct in6_addr));
            memcpy(&psNetworkContext->u64IPv6Prefix, &psReceivedPacket->sRecv_addr.sin6_addr, sizeof(uint64_t));
        }
        
        DBG_vPrintf(DBG_NETWORK, "  Packet OK");
        
        /* Copy the data from the queue, and free the structure */
        *iDataLength = psReceivedPacket->iBytesRecieved;
        memcpy(pcData, psReceivedPacket->acBuffer, psReceivedPacket->iBytesRecieved);
        free(psReceivedPacket);
    
        return E_NETWORK_OK;
    }
}


teNetworkStatus Network_ExchangeJIP(tsNetworkContext *psNetworkContext, tsJIPAddress *psAddress, uint32_t u32Retries,
                                     teJIP_Command eSendCommand, const char *pcSendData, int iSendDataLength, 
                                     teJIP_Command eReceiveCommand, char *pcReceiveData, unsigned int *piReceiveDataLength)
{
    teNetworkStatus eStatus;
    uint32_t i;
    tsJIP_MsgHeader *psSendHeader;
    tsJIP_MsgHeader *psReceiveHeader;
    static uint8_t u8Handle = 0;
        
    DBG_vPrintf(DBG_FUNCTION_CALLS, "%s\n", __FUNCTION__);
    
    char *SendBuffer = alloca(sizeof(tsJIP_MsgHeader) + iSendDataLength);
    
    if (!SendBuffer)
    {
        return E_NETWORK_ERROR_NO_MEM;
    }
    
    psSendHeader = (tsJIP_MsgHeader *)pcSendData;//SendBuffer;
    
    psSendHeader->u8Version = JIP_VERSION;
    psSendHeader->eCommand  = eSendCommand;
    psSendHeader->u8Handle  = ++u8Handle;
    
    //memcpy(&SendBuffer[sizeof(tsJIP_MsgHeader)], pcSendData, iSendDataLength);
    
    for (i = 0; i < u32Retries; i++)
    {
        if((eStatus = Network_Send(psNetworkContext, psAddress, pcSendData, 
            iSendDataLength)) != E_NETWORK_OK)
        {
            DBG_vPrintf(DBG_NETWORK, "Error sending data (%d) on attempt %d\n", eStatus, i);
            continue;
        }
        
        while (eStatus == E_NETWORK_OK)
        {
            eStatus = Network_Recieve(psNetworkContext, psAddress, pcReceiveData, piReceiveDataLength);
            if (eStatus == E_NETWORK_OK)
            {
                /* We got a packet - see if it matches what we expect */
                psReceiveHeader = (tsJIP_MsgHeader *)pcReceiveData; 
            
                if (psReceiveHeader->u8Version != JIP_VERSION)
                {
                    /* Check version */
                    DBG_vPrintf(DBG_NETWORK, "Version mismatch!\n");
                    continue;
                }
                
                if (psReceiveHeader->eCommand != eReceiveCommand)
                {
                    DBG_vPrintf(DBG_NETWORK, "Unexpected response!\n");
                    continue;
                }
                
                if (psReceiveHeader->u8Handle != psSendHeader->u8Handle)
                {
                    /* Check handle matches */
                    DBG_vPrintf(DBG_NETWORK, "Handle mismatch!\n");
                    continue;
                }

                DBG_vPrintf(DBG_NETWORK, "Packet OK\n");
                /* Return the packet */
                return E_NETWORK_OK;
            }
            else
            {
                /* No packet received,or an error occured - retransmit */
                break; /* From the while loop */
            }
        }
    }

    return E_NETWORK_ERROR_FAILED;
}

teNetworkStatus Network_SendJIP(tsNetworkContext *psNetworkContext, tsJIPAddress *psAddress,
                                     teJIP_Command eCommand, const char *pcSendData, int iDataLength)
{
    tsJIP_MsgHeader *psSendHeader;
        
    DBG_vPrintf(DBG_FUNCTION_CALLS, "%s\n", __FUNCTION__);
    
    char *SendBuffer = alloca(sizeof(tsJIP_MsgHeader) + iDataLength);
    
    if (!SendBuffer)
    {
        return E_NETWORK_ERROR_NO_MEM;
    }
    
    psSendHeader = (tsJIP_MsgHeader *)pcSendData;
    
    psSendHeader->u8Version = JIP_VERSION;
    psSendHeader->eCommand  = eCommand;
    psSendHeader->u8Handle  = rand() * 255; /* Probably not the best way of generating a handle ever */
    
    //memcpy(&SendBuffer[sizeof(tsJIP_MsgHeader)], pcData, iDataLength);
    
    return Network_Send(psNetworkContext, psAddress, pcSendData, iDataLength);
}



#if defined USE_INTERNAL_BYTESWAP_64

uint64_t bswap_64(uint64_t x)
{
    uint64_t y;
    
    y = ((((uint64_t)__bswap_32(x) & 0x00000000FFFFFFFFL) << 32) | (((uint64_t)__bswap_32(x >> 32) & 0x00000000FFFFFFFFL)));
    
    return y;
}

#endif /* _UCLIBC_ */

