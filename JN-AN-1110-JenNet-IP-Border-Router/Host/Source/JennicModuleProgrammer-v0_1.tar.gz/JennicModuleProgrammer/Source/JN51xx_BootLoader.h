/****************************************************************************
 *
 * MODULE:             JN51xx_BootLoader
 *
 * COMPONENT:          $RCSfile: JN51xx_BootLoader.h,v $
 *
 * VERSION:            $Name:  $
 *
 * REVISION:           $Revision: 1.1 $
 *
 * DATED:              $Date: 2008/10/17 10:22:11 $
 *
 * STATUS:             $State: Exp $
 *
 * AUTHOR:             Lee Mitchell
 *
 * DESCRIPTION:
 *
 * LAST MODIFIED BY:   $Author: lmitch $
 *                     $Modtime: $
 *
 *
 ****************************************************************************
 *
 * This software is owned by NXP B.V. and/or its supplier and is protected
 * under applicable copyright laws. All rights are reserved. We grant You,
 * and any third parties, a license to use this software solely and
 * exclusively on NXP products [NXP Microcontrollers such as JN5148, JN5142, JN5139]. 
 * You, and any third parties must reproduce the copyright and warranty notice
 * and any other legend of ownership on each copy or partial copy of the 
 * software.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.

 * Copyright NXP B.V. 2012. All rights reserved
 *
 ***************************************************************************/

#ifndef  JN51XX_BOOTLOADER_H_INCLUDED
#define  JN51XX_BOOTLOADER_H_INCLUDED

#if defined __cplusplus
extern "C" {
#endif

/****************************************************************************/
/***        Include files                                                 ***/
/****************************************************************************/

#include <stdint.h>

#include <Firmware.h>

/****************************************************************************/
/***        Macro Definitions                                             ***/
/****************************************************************************/

/****************************************************************************/
/***        Type Definitions                                              ***/
/****************************************************************************/


/** Enumerated type of Jennic devices */
typedef enum
{
    E_CHIPID_JN5121         = 0x00,
    E_CHIPID_JN5139         = 0x02,
    E_CHIPID_JN5148         = 0x04,
    E_CHIPID_JN5142         = 0x05,
} teChipID;


/** Enumerated type of Flash manufacturers */
typedef enum 
{
    E_FLASH_MAN_ST          = 0x10,
    E_FLASH_MAN_ATMEL       = 0x1F,
    E_FLASH_MAN_SST         = 0xBF,
    E_FLASH_MAN_INTERNAL    = 0xCC,
} teFlashManufacturer;


/** Enumerated type of Flash Devices */
typedef enum
{
    /* ST Devices */
    E_FLASH_ID_STM25P10A    = 0x10,
    E_FLASH_ID_STM25P20     = 0x11,
    E_FLASH_ID_STM25P40     = 0x12,
    E_FLASH_ID_STM25P05     = 0x05,

    /* Atmel Devices */
    E_FLASH_ID_AT25F512     = 0x60,
    E_FLASH_ID_AT25F512A    = 0x65,

    /* SST Devices */
    E_FLASH_ID_SST25VF512   = 0x48,
    E_FLASH_ID_SST25VF010   = 0x49,
    E_FLASH_ID_SST25VF020   = 0x43,
    E_FLASH_ID_SST25VF040B  = 0x8D,
    
    /* Internal Flash */
    E_FLASH_ID_INTJN516x    = 0xEE,
} teFlashDevice;


/** Structure Contatining Imformation about connected device */
typedef struct
{
    teChipID            eChipID;
    uint16_t            u16ChipRevision;
    uint16_t            u16Mask;
    
    uint32_t            u32ROMVersion;
    uint64_t            u64MacAddress;
    
    teFlashManufacturer eFlashManufacturer;
    teFlashDevice       eFlashDevice;
    uint32_t            u32FlashNumSectors;
    
} tsModuleDetails;


/****************************************************************************/
/***        Local Function Prototypes                                     ***/
/****************************************************************************/

/****************************************************************************/
/***        Exported Variables                                            ***/
/****************************************************************************/

/****************************************************************************/
/***        Local Variables                                               ***/
/****************************************************************************/

/****************************************************************************/
/***        Exported Functions                                            ***/
/****************************************************************************/

void vBL_Init(void);

int iBL_SetBaud(int iBaudrate);

int iBL_GetModuleDetails(tsModuleDetails *psModuleDetails);

int iBL_GetMacAddress(tsFW_Info *psFW_Info, uint8_t *pu8MacAddress);

int iBL_DownloadFirmwareToRam(tsFW_Info *psFW_Info, uint64_t *pu64MAC_Address);

int iBL_DownloadFirmwareToFlash(tsFW_Info *psFW_Info, int iVerify);




/****************************************************************************/
/***        Local Functions                                               ***/
/****************************************************************************/

#if defined __cplusplus
}
#endif

#endif  /* JN51XX_BOOTLOADER_H_INCLUDED */

/****************************************************************************/
/***        END OF FILE                                                   ***/
/****************************************************************************/

