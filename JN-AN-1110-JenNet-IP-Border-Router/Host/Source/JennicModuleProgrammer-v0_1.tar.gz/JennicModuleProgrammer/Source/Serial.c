/****************************************************************************
 *
 * MODULE:             Jennic Module Programmer
 *
 * COMPONENT:          Serial port handling
 *
 * VERSION:            $Name:  $
 *
 * REVISION:           $Revision: 1.2 $
 *
 * DATED:              $Date: 2009/03/02 13:33:44 $
 *
 * STATUS:             $State: Exp $
 *
 * AUTHOR:             Matt Redfearn
 *
 * DESCRIPTION:
 *
 *
 * LAST MODIFIED BY:   $Author: lmitch $
 *                     $Modtime: $
 *
 ****************************************************************************
 *
 * This software is owned by NXP B.V. and/or its supplier and is protected
 * under applicable copyright laws. All rights are reserved. We grant You,
 * and any third parties, a license to use this software solely and
 * exclusively on NXP products [NXP Microcontrollers such as JN5148, JN5142, JN5139]. 
 * You, and any third parties must reproduce the copyright and warranty notice
 * and any other legend of ownership on each copy or partial copy of the 
 * software.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.

 * Copyright NXP B.V. 2012. All rights reserved
 *
 ***************************************************************************/

#include "Serial.h"

#include <termios.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <fcntl.h>
#include <sys/select.h>
#include <sys/signal.h>
#include <sys/types.h>
#include <sys/time.h>
#include <errno.h>


static int serial_fd;

static struct termios options;       //place for settings for serial port
char buf[255];                       //buffer for where data is put


int serial_open(char *name, int initial_baud)
{
    int fd;
    
    printf("Using serial device %s\n", name);
    
    //open the device(com port) to be non-blocking (read will return immediately)
    fd = open(name, O_RDWR | O_NOCTTY);// | O_NONBLOCK | O_NDELAY);
    if (fd < 0)
    {
        perror("Couldn't open device");
        return -1;
    }

    if (tcgetattr(fd,&options) == -1)
    {
        perror("Error getting port settings");
        return -1;
    }

    options.c_iflag &= ~(INPCK | ISTRIP | INLCR | IGNCR | ICRNL | IUCLC | IXON | IXANY | IXOFF);
    options.c_iflag = IGNBRK | IGNPAR;
    options.c_oflag &= ~(OPOST | OLCUC | ONLCR | OCRNL | ONOCR | ONLRET);
    options.c_cflag &= ~(CSIZE | CSTOPB | PARENB | CRTSCTS);
    options.c_cflag |= CS8 | CREAD | HUPCL | CLOCAL;
    options.c_lflag &= ~(ISIG | ICANON | ECHO | IEXTEN);

    fcntl(fd, F_SETFL, O_NONBLOCK);
    
    serial_fd = fd;
    
    return serial_baud(initial_baud);
}


int serial_baud(int baud)
{
    int defined_baud;
    
    switch (baud)
    {
#define BAUD(rate) case(rate): defined_baud = B##rate;break
        BAUD(38400);
        BAUD(115200);
        BAUD(230400);
        BAUD(460800);
        BAUD(500000);
        BAUD(921600);
        BAUD(1000000);
#undef BAUD
        default:
            fprintf(stderr, "Unsupported baud rate: %d\n", baud);
            return -1;
    }       
    
    tcflush(serial_fd, TCIOFLUSH);

    cfsetispeed(&options, defined_baud);
    cfsetospeed(&options, defined_baud);

    if (tcsetattr(serial_fd,TCSANOW,&options) == -1)
    {
        perror("Error setting port settings");
        return -1;
    }
    return 0;
}


#define SERIAL_USE_SELECT

int serial_read(unsigned char *data)
{
    signed char         iResult = -1;
    
#ifdef SERIAL_USE_SELECT
    struct timeval      sTimeout;
    fd_set              sFileDescriptors;
    int                 iMaxFd;    

    sTimeout.tv_usec = 0;  /* milliseconds */
    sTimeout.tv_sec  = 5;  /* seconds */
    
    FD_ZERO(&sFileDescriptors);
    iMaxFd = serial_fd;
    FD_SET(serial_fd, &sFileDescriptors);
    
    iResult = select(iMaxFd + 1, &sFileDescriptors, NULL, NULL, &sTimeout);
    if (iResult < 0)
    {
        perror("Error reading from serial device");
    }
    else if (iResult == 0)
    {
        fprintf(stderr, "Timeout communicating with module\n");
        iResult = -1;
    }
    else
    {
#endif /* SERIAL_USE_SELECT */
        if (FD_ISSET(serial_fd, &sFileDescriptors))
        {
            iResult = read(serial_fd,data,1);
            if (iResult > 0)
            {
                //printf("Char received 0x%02x (return %d)\n", *data, iResult);
            }
            else
            {
                //printf("Serial read: %d\n", iResult);
                iResult = 0;
            }
        }
#ifdef SERIAL_USE_SELECT
    }
    

#endif /* SERIAL_USE_SELECT */
    
    return iResult;
}

int serial_write(const unsigned char data)
{
    int err, attempts = 0;
    //printf("send char %d\n", data);
    
    err = write(serial_fd,&data,1);
    if (err < 0)
    {
        if (errno == EAGAIN)
        {
            for (attempts = 0; attempts <= 5; attempts++)
            {
                usleep(1000);
                err = write(serial_fd,&data,1);
                if (err < 0) 
                {
                    if ((errno == EAGAIN) && (attempts == 5))
                    {
                        perror("Could not write to serial device");
                        exit(-1);
                    }
                }
                else
                {
                    break;
                }
            }
        }
        else
        {
            printf("Error %d\n", err);
            perror("Could not write");
            exit(-1);
        }
    }
    return 0;
}

int serial_write_buffer(unsigned char *data, int count)
{
    //printf("send char %d\n", data);
    int total_sent_bytes = 0, sent_bytes = 0;
    
    while (total_sent_bytes < count)
    {
        sent_bytes = write(serial_fd, data, count);
        if (count < 0)
        {
            perror("Could not write");
            exit(-1);
        }
        total_sent_bytes += sent_bytes;
    }
    return total_sent_bytes;
}


