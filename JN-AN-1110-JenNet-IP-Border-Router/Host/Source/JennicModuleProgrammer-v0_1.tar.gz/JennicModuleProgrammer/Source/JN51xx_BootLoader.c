/****************************************************************************
 *
 * MODULE:             JN51xx_BootLoader
 *
 * COMPONENT:          $RCSfile: JN51xx_BootLoader.c,v $
 *
 * VERSION:            $Name:  $
 *
 * REVISION:           $Revision: 1.2 $
 *
 * DATED:              $Date: 2009/03/02 13:33:44 $
 *
 * STATUS:             $State: Exp $
 *
 * AUTHOR:             Lee Mitchell
 *
 * DESCRIPTION:
 *
 *
 * LAST MODIFIED BY:   $Author: lmitch $
 *                     $Modtime: $
 *
 ****************************************************************************
 *
 * This software is owned by NXP B.V. and/or its supplier and is protected
 * under applicable copyright laws. All rights are reserved. We grant You,
 * and any third parties, a license to use this software solely and
 * exclusively on NXP products [NXP Microcontrollers such as JN5148, JN5142, JN5139]. 
 * You, and any third parties must reproduce the copyright and warranty notice
 * and any other legend of ownership on each copy or partial copy of the 
 * software.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.

 * Copyright NXP B.V. 2012. All rights reserved
 *
 ***************************************************************************/

#ifdef DEBUG_JN51XX_BOOTLOADER
#define DEBUG_ENABLE
#endif

/****************************************************************************/
/***        Include files                                                 ***/
/****************************************************************************/

#include <stdio.h>
#include <endian.h>
#include <arpa/inet.h>
#include <unistd.h>
#include <stdint.h>
#include <string.h>

#include "Serial.h"
#include "Firmware.h"
#include "JN51xx_BootLoader.h"


/****************************************************************************/
/***        Macro Definitions                                             ***/
/****************************************************************************/

#define BL_MAX_CHUNK_SIZE	248


#define DEBUG

#ifdef DEBUG
#define vDebug(...) printf(__VA_ARGS__)
#else
#define vDebug(...)
#endif 

/****************************************************************************/
/***        Type Definitions                                              ***/
/****************************************************************************/

typedef enum
{
	E_BL_MSG_TYPE_FLASH_ERASE_REQUEST 					= 0x07,
	E_BL_MSG_TYPE_FLASH_ERASE_RESPONSE					= 0x08,
	E_BL_MSG_TYPE_FLASH_PROGRAM_REQUEST					= 0x09,
	E_BL_MSG_TYPE_FLASH_PROGRAM_RESPONSE				= 0x0a,
	E_BL_MSG_TYPE_FLASH_READ_REQUEST					= 0x0b,
	E_BL_MSG_TYPE_FLASH_READ_RESPONSE					= 0x0c,
	E_BL_MSG_TYPE_FLASH_SECTOR_ERASE_REQUEST			= 0x0d,
	E_BL_MSG_TYPE_FLASH_SECTOR_ERASE_RESPONSE			= 0x0e,
	E_BL_MSG_TYPE_FLASH_WRITE_STATUS_REGISTER_REQUEST	= 0x0f,
	E_BL_MSG_TYPE_FLASH_WRITE_STATUS_REGISTER_RESPONSE	= 0x10,
	E_BL_MSG_TYPE_RAM_WRITE_REQUEST						= 0x1d,
	E_BL_MSG_TYPE_RAM_WRITE_RESPONSE					= 0x1e,
	E_BL_MSG_TYPE_RAM_READ_REQUEST						= 0x1f,
	E_BL_MSG_TYPE_RAM_READ_RESPONSE						= 0x20,
	E_BL_MSG_TYPE_RAM_RUN_REQUEST						= 0x21,
	E_BL_MSG_TYPE_RAM_RUN_RESPONSE						= 0x22,
	E_BL_MSG_TYPE_FLASH_READ_ID_REQUEST					= 0x25,
	E_BL_MSG_TYPE_FLASH_READ_ID_RESPONSE				= 0x26,
	E_BL_MSG_TYPE_SET_BAUD_REQUEST						= 0x27,
	E_BL_MSG_TYPE_SET_BAUD_RESPONSE						= 0x28,
	E_BL_MSG_TYPE_FLASH_SELECT_TYPE_REQUEST				= 0x2c,
	E_BL_MSG_TYPE_FLASH_SELECT_TYPE_RESPONSE			= 0x2d,
    
    E_BL_MSG_TYPE_GET_CHIPID_REQUEST                    = 0x32,
    E_BL_MSG_TYPE_GET_CHIPID_RESPONSE                   = 0x33,
} __attribute ((packed)) teBL_MessageType;


typedef enum
{
	E_BL_RESPONSE_OK									= 0x00,
	E_BL_RESPONSE_NOT_SUPPORTED							= 0xff,
	E_BL_RESPONSE_WRITE_FAIL							= 0xfe,
	E_BL_RESPONSE_INVALID_RESPONSE						= 0xfd,
	E_BL_RESPONSE_CRC_ERROR								= 0xfc,
	E_BL_RESPONSE_ASSERT_FAIL							= 0xfb,
	E_BL_RESPONSE_USER_INTERRUPT						= 0xfa,
	E_BL_RESPONSE_READ_FAIL								= 0xf9,
	E_BL_RESPONSE_TST_ERROR								= 0xf8,
	E_BL_RESPONSE_AUTH_ERROR							= 0xf7,
	E_BL_RESPONSE_NO_RESPONSE							= 0xf6,
	E_BL_RESPONSE_ERROR									= 0xf0,
} __attribute__ ((packed)) teBL_Response;


/** Structure containing a lookup between IDs and string names */
typedef struct
{
    uint32_t                u32Length;              /**< Number of pairs in the array */
    struct {
        int                 iID;                    /**< ID */
        const char *        pcName;                 /**< Name representing this ID */
    } asPairs[];                                    /**< Variable array of ID to Name pairs */
} tsIDNameLookup;


/****************************************************************************/
/***        Local Function Prototypes                                     ***/
/****************************************************************************/

/** Function to lookup a printable name based on an ID.
 *  ID/Name pairs are taken from a \ref tsIDNameLookup structure.
 *  \param psIDNameLookup       Pointer to lookup structure
 *  \param iID                  ID to find.
 *  \return String for name, or "Unknown" if not found.
 */
static const char *pcGetName (tsIDNameLookup *psIDNameLookup, int iID);

static teBL_Response eBL_Request(teBL_MessageType eTxType, uint8_t u8HeaderLen, uint8_t *pu8Header, uint8_t u8TxLength, uint8_t *pu8TxData, teBL_MessageType *peRxType, uint8_t *pu8RxLength, uint8_t *pu8RxData);

static int iBL_WriteMessage(teBL_MessageType eType, uint8_t u8HeaderLength, uint8_t *pu8Header, uint8_t u8Length, uint8_t *pu8Data);
static teBL_Response eBL_ReadMessage(teBL_MessageType *peType, uint8_t *pu8Length, uint8_t *pu8Data);

static void vBL_WriteByte(uint8_t u8Data, uint8_t *pu8CheckSum);
static uint8_t u8BL_ReadByte(uint8_t *pu8Data, uint8_t *pu8CheckSum);



static int iBL_RunRAM(uint32_t u32Address);
static int iBL_ReadRAM(uint32_t u32Address, uint8_t u8Length, uint8_t *pu8Buffer);
static int iBL_WriteRAM(uint32_t u32Address, uint8_t u8Length, uint8_t *pu8Buffer);


static int iBL_EraseFlash(void);
static int iBL_ReadFlash(uint32_t u32Address, uint8_t u8Length, uint8_t *pu8Buffer);
static int iBL_WriteFlash(uint32_t u32Address, uint8_t u8Length, uint8_t *pu8Buffer);

/****************************************************************************/
/***        Exported Variables                                            ***/
/****************************************************************************/

extern int iVerbosity;

/****************************************************************************/
/***        Local Variables                                               ***/
/****************************************************************************/

/** Lookup for Chip IDs */
static tsIDNameLookup sChipIDNames = 
{
    .u32Length = 4,
    .asPairs =
    {
        {E_CHIPID_JN5121,       "JN5121"},
        {E_CHIPID_JN5139,       "JN5139"},
        {E_CHIPID_JN5148,       "JN5148"},
        {E_CHIPID_JN5142,       "JN5142"},
    }
};


/** Lookup for ROM IDs */
static tsIDNameLookup sROMNames = 
{
    .u32Length = 2,
    .asPairs =
    {
        {0x01060035,            "001"},         /**< JN5148-001 */
        {0x02060036,            "J01"},         /**< JN5148-J01 */
    }
};


/** Lookup of Flash devices */
static tsIDNameLookup sFlashIDNames = 
{
    .u32Length = 11,
    .asPairs =
    {
        {E_FLASH_ID_STM25P10A,      "ST M25P10A"},
        {E_FLASH_ID_STM25P20,       "ST M25P20"},
        {E_FLASH_ID_STM25P40,       "ST M25P40"},
        {E_FLASH_ID_STM25P05,       "ST M25P05"},
        
        {E_FLASH_ID_AT25F512,       "Atmel 25F512"},
        {E_FLASH_ID_AT25F512A,      "Atmel 25F512A"},
        
        {E_FLASH_ID_SST25VF512,     "SST 25VF512"},
        {E_FLASH_ID_SST25VF010,     "SST 25VF010"},
        {E_FLASH_ID_SST25VF020,     "SST 25VF020"},
        {E_FLASH_ID_SST25VF040B,    "SST 25VF040B"},
        
        {E_FLASH_ID_INTJN516x,      "JN516x Internal"},
    }
};


/****************************************************************************/
/***        Exported Functions                                            ***/
/****************************************************************************/

/****************************************************************************
 *
 * NAME: vBL_Init
 *
 * DESCRIPTION:
 *	Initialises boot loader functions.
 *tsFW_Info
 * PARAMETERS: Name        RW  Usage
 *
 * RETURNS:
 * void
 ****************************************************************************/
void vBL_Init(void)
{

	/* Bootloader on JN513x starts up at 1Mbaud for first 100mS, then drops
	 * to 38400. So, if we start to communicate with it within the first 100mS
	 * there is no need to start off at a lower baudrate and then up it later
	 */

	//vUartInit(BL_UART, B38400);

}


int iBL_SetBaud(int iBaudrate)
{
    uint8_t au8CmdBuffer[3];
    
    switch(iBaudrate)
    {
        // Set divisor as appropriate for selected baud rate
        case (38400):       au8CmdBuffer[0] = 26;   break;
        case (115200):      au8CmdBuffer[0] = 9;    break;
        case (230400):      au8CmdBuffer[0] = 4;    break;
        case (460800):      au8CmdBuffer[0] = 2;    break;
        case (500000):      au8CmdBuffer[0] = 2;    break;
        case (921600):      au8CmdBuffer[0] = 1;    break;
        case (1000000):     au8CmdBuffer[0] = 1;    break;
        default: fprintf(stderr, "Cannot set baudrate %d in bootloader\n", iBaudrate); return -1;
    }
#if 0
    {
        uint8_t au8Buffer[6];
        uint8_t u8RxDataLen = 0;
        teBL_Response eResponse = 0;
        teBL_MessageType eRxType = 0;

        eResponse = eBL_Request(E_BL_MSG_TYPE_SET_BAUD_REQUEST, 1, au8CmdBuffer, 0, NULL, &eRxType, &u8RxDataLen, au8Buffer);
        if(eResponse != E_BL_RESPONSE_OK || eRxType != E_BL_MSG_TYPE_SET_BAUD_RESPONSE)
        {
            fprintf(stderr, "Failed to set High baud rate (%d, %d)\n",eResponse, eRxType );
        }
    }
    /* Don't use normal method because CRC byte gets corrupted. Just send the message, wait 500ms then change speed. */
#else
    /* Send message */
    if(iBL_WriteMessage(E_BL_MSG_TYPE_SET_BAUD_REQUEST, 1, au8CmdBuffer, 0, NULL) == -1)
    {
        return -1;
    }
    
    // Just delay 500ms here.
    usleep(500000);
#endif

    return 0;
}


int iBL_GetModuleDetails(tsModuleDetails *psModuleDetails)
{
    uint8_t u8RxDataLen = 0;
    uint8_t au8Buffer[6];
    teBL_Response eResponse = 0;
    teBL_MessageType eRxType = 0;
    uint32_t u32ChipID, u32ROMVersion;

    eResponse = eBL_Request(E_BL_MSG_TYPE_GET_CHIPID_REQUEST, 0, NULL, 0, NULL, &eRxType, &u8RxDataLen, au8Buffer);
    if(eResponse != E_BL_RESPONSE_OK || eRxType != E_BL_MSG_TYPE_GET_CHIPID_RESPONSE)
    {
        /* Failed to read chip ID - Maybe an older device - read the Processor ID register */
        
        if (iBL_ReadRAM(0x100000FC, 4, au8Buffer) < 0)
        {
            fprintf(stderr, "Error Reading processor ID register\n");
            return -1;
        }
    }
    
    u32ChipID = ntohl(*(uint32_t *)au8Buffer);
    
    if (u32ChipID == 0x00200000)
    {
        /* JN5139 */
        psModuleDetails->eChipID            = E_CHIPID_JN5139;
    }
    else
    {
        psModuleDetails->u16ChipRevision    = (u32ChipID  >> 28 ) & 0x0000000F;
        psModuleDetails->eChipID            = (u32ChipID  >> 12 ) & 0x000003FF;
        psModuleDetails->u16Mask            = (u32ChipID  >> 22 ) & 0x0000003F;
    }

    if (iBL_ReadRAM(0x00000004, 4, au8Buffer) < 0)
    {
        fprintf(stderr, "Error reading ROM version\n");
        return -1;
    }
    
    u32ROMVersion = ntohl(*(uint32_t *)au8Buffer);
    
    psModuleDetails->u32ROMVersion = u32ROMVersion;
    
    // Special case for JN5148-J01.
    if ((psModuleDetails->eChipID           == E_CHIPID_JN5148) &&
        (psModuleDetails->u16ChipRevision   == 1) &&
        (psModuleDetails->u32ROMVersion     == 0x02060036))
    {
        psModuleDetails->u16Mask = 222;
    }

    printf("Detected Chip:      %s-%s\n", pcGetName(&sChipIDNames, psModuleDetails->eChipID), pcGetName(&sROMNames, psModuleDetails->u32ROMVersion));

    if (iVerbosity > 1)
    {
        printf("  Chip Type: 0x%04x, revision: 0x%04x, mask: 0x04%x. ROM 0x%08x\n", 
               psModuleDetails->eChipID, psModuleDetails->u16ChipRevision, psModuleDetails->u16Mask, psModuleDetails->u32ROMVersion);
    }    
    
    eResponse = eBL_Request(E_BL_MSG_TYPE_FLASH_READ_ID_REQUEST, 0, NULL, 0, NULL, &eRxType, &u8RxDataLen, au8Buffer);
    if(eResponse != E_BL_RESPONSE_OK || eRxType != E_BL_MSG_TYPE_FLASH_READ_ID_RESPONSE)
    {
        /* Failed to read Flash ID */
        fprintf(stderr, "Could not read Flash type!\n");
        return -1;
    }
    
    psModuleDetails->eFlashManufacturer     = au8Buffer[0];
    psModuleDetails->eFlashDevice           = au8Buffer[1];

    
    printf("Detected Flash:     %s \n", pcGetName(&sFlashIDNames, psModuleDetails->eFlashDevice));
    
    if (iVerbosity > 1)
    {
        printf("  Flash Manufacturer: 0x%02x, Part: 0x%02x\n", psModuleDetails->eFlashManufacturer, psModuleDetails->eFlashDevice);
    }

    /* Set up number of Flash sectors */
    //psModuleDetails->u32FlashNumSectors;
    
    return 0;
}


int iBL_GetMacAddress(tsFW_Info *psFW_Info, uint8_t *pu8MacAddress)
{
    /* Read MAC Address into file image */
    if (iVerbosity > 2)
    {
        printf("Read MAC address from offset 0x%08x\n", psFW_Info->u32MacAddressLocation);
    }
    
    if(iBL_ReadFlash(psFW_Info->u32MacAddressLocation, 16, pu8MacAddress) != 16)
    {
        fprintf(stderr, "Failed to read module's MAC address\n");
        return(-1);
    }
    return 0;
}



/****************************************************************************
 *
 * NAME: iBL_DownloadFirmwareToRam
 *
 * DESCRIPTION:
 *	Downloads the given firmware to the module's RAM.
 *	see \ZED-TL\Sw\Source\boot.c for details
 *
 * PARAMETERS: 	Name        	RW  Usage
 * 				pu8Firmware		R	Pointer to firmware image to download
 * 				pu64Address     R   Pointer to MAC Address. If NULL, read from flash.
 *
 * RETURNS:
 * int			0 if success
 * 				-1 if an error occured
 *
 ****************************************************************************/
int iBL_DownloadFirmwareToRam(tsFW_Info *psFW_Info, uint64_t *pu64MAC_Address)
{
	int n;
	uint8_t u8ChunkSize;

// 	if(psBinHeader->u8ConfigByte0 == 0xff && psBinHeader->u8ConfigByte1 == 0xff && psBinHeader->u16SpiScrambleIndex == 0xffff)
// 	{
// 		vDebug("\nFlash image is invalid, aborting.");
// 		return(-1);
// 	}

	vDebug("\nText Start 0x%08x - Len %d bytes", psFW_Info->u32TextSectionLoadAddress, psFW_Info->u32TextSectionLength);
	vDebug("\nBSS  Start 0x%08x - Len %d bytes", psFW_Info->u32BssSectionLoadAddress, psFW_Info->u32BssSectionLength);
	vDebug("\nReset entry point 0x%08x", ntohl(psFW_Info->u32ResetEntryPoint));
    vDebug("\nWake entry point 0x%08x",  ntohl(psFW_Info->u32WakeUpEntryPoint));
    
    printf("\nHeader is at %p\n", psFW_Info->pu8ImageData);
    printf("Text Start  at %p\n", psFW_Info->pu8TextData);
    
#if 0
    if (pu64MAC_Address)
    {
        uint64_t u64Temp;
        u64Temp = htobe64(*pu64MAC_Address);
        memset(au8Buffer, 0, 12);
        memcpy(au8Buffer, &u64Temp, sizeof(uint64_t));
    }
    else
    {
        vDebug("Reading module MAC address from flash.\n");
        /* Read out the module's MAC address & license key, we need to write them back to RAM */
        if(iBL_ReadFlash(MAC_ADDR_LOCATION, 12, au8Buffer) != 12)
        {
            vDebug("\nFailed to read module's MAC address");
            return(-1);
        }
    }
#endif
//     vDebug("\nLoading .text\n");
    /* Download text segment */
    for(n = 0; n < psFW_Info->u32TextSectionLength;)
    {
        if((psFW_Info->u32TextSectionLength - n) > BL_MAX_CHUNK_SIZE)
        {
            u8ChunkSize = BL_MAX_CHUNK_SIZE;
        }
        else
        {
            u8ChunkSize = psFW_Info->u32TextSectionLength - n;
        }
        
        if(iBL_WriteRAM(psFW_Info->u32TextSectionLoadAddress + n, u8ChunkSize, psFW_Info->pu8TextData + n) == -1)
        {
            vDebug("\nProblem writing chunk");
            return(-1);
        }

        printf("Wrote chunk length %d at address 0x%08x: 0x%08x\n", u8ChunkSize, psFW_Info->u32TextSectionLoadAddress + n, ntohl(*((uint32_t*)(psFW_Info->pu8TextData + n))));
        
        if (1)
        {
            uint8_t au8Buffer[BL_MAX_CHUNK_SIZE + 1];
            if (iBL_ReadRAM(psFW_Info->u32TextSectionLoadAddress + n, u8ChunkSize, au8Buffer) == -1)
            {
                printf("Error reading at address 0x%08x\n", psFW_Info->u32TextSectionLoadAddress + n);
                return -1;
            }
            else
            {
                if (memcmp(psFW_Info->pu8TextData + n, au8Buffer, u8ChunkSize))
                {
                    printf("Data read at address 0x%08x is incorrect\n", psFW_Info->u32TextSectionLoadAddress + n);
                    return -1;
                }
            }
        }
        
        n += u8ChunkSize;
        
        //vDebug("Loading: %3d%%\n%c[A", (n * 100) / psFW_Info->u32TextSectionLength, 0x1B);
        vDebug("Loading: %3d%%\n", (n * 100) / psFW_Info->u32TextSectionLength);
    }
	
	/* Write back MAC address & license key */
// 	if(iBL_WriteRAM(psFW_Info->u32TextSectionLoadAddress, 12, au8Buffer) == -1)
// 	{
// 		vDebug("\nProblem writing chunk");
// 		return(-1);
// 	}
#if 1
	vDebug("\nLoading .bss     \n");

    /* Download BSS segment */
    {
        uint8_t au8Buffer[127];
        memset(au8Buffer, 0, sizeof(au8Buffer));
        for(n = 0; n < psFW_Info->u32BssSectionLength;)
        {
            if((psFW_Info->u32BssSectionLength - n) > sizeof(au8Buffer))
            {
                u8ChunkSize = sizeof(au8Buffer);
            }
            else
            {
                u8ChunkSize = psFW_Info->u32BssSectionLength - n;
            }
            if(iBL_WriteRAM(psFW_Info->u32BssSectionLoadAddress + n, u8ChunkSize, au8Buffer) == -1)
            {
                vDebug("\nProblem writing BSS");
                return(-1);
            }

            n += u8ChunkSize;

            vDebug("Loading: %3d%%\n%c[A", (n * 100) / psFW_Info->u32BssSectionLength, 0x1B);
        }
    }
#endif

    vDebug("\nStarting module application");
    iBL_RunRAM(psFW_Info->u32ResetEntryPoint);

	return(0);
}


/****************************************************************************
 *
 * NAME: iBL_RunRAM
 *
 * DESCRIPTION:
 *	Starts the module executing code from a given address
 *
 * PARAMETERS: Name        RW  Usage
 *
 * RETURNS:
 * int			0 if success
 * 				-1 if an error occured
 *
 ****************************************************************************/
static int iBL_RunRAM(uint32_t u32Address)
{
	uint8_t u8RxDataLen = 0;
	uint8_t au8CmdBuffer[4];
	teBL_Response eResponse = 0;
	teBL_MessageType eRxType = 0;

	au8CmdBuffer[0] = (uint8_t)(u32Address >> 0) & 0xff;
	au8CmdBuffer[1] = (uint8_t)(u32Address >> 8) & 0xff;
	au8CmdBuffer[2] = (uint8_t)(u32Address >> 16) & 0xff;
	au8CmdBuffer[3] = (uint8_t)(u32Address >> 24) & 0xff;

	eResponse = eBL_Request(E_BL_MSG_TYPE_RAM_RUN_REQUEST, 4, au8CmdBuffer, 0, NULL, &eRxType, &u8RxDataLen, NULL);
	if(eResponse != E_BL_RESPONSE_OK || eRxType != E_BL_MSG_TYPE_RAM_RUN_RESPONSE)
	{
		fprintf(stderr, "%s: Response %02x", __FUNCTION__, eResponse);
		return(-1);
	}

	return(0);
}

/****************************************************************************
 *
 * NAME: iBL_ReadRAM
 *
 * DESCRIPTION:
 *
 * PARAMETERS: Name        RW  Usage
 *
 * RETURNS:
 * int			0 if success
 * 				-1 if an error occured
 *
 ****************************************************************************/
static int iBL_ReadRAM(uint32_t u32Address, uint8_t u8Length, uint8_t *pu8Buffer)
{
	uint8_t u8RxDataLen = 0;
	uint8_t au8CmdBuffer[6];
	teBL_Response eResponse = 0;
	teBL_MessageType eRxType = 0;

	if(u8Length > 0xfc)
	{
		return(-1);
	}

	au8CmdBuffer[0] = (uint8_t)(u32Address >> 0) & 0xff;
	au8CmdBuffer[1] = (uint8_t)(u32Address >> 8) & 0xff;
	au8CmdBuffer[2] = (uint8_t)(u32Address >> 16) & 0xff;
	au8CmdBuffer[3] = (uint8_t)(u32Address >> 24) & 0xff;
	au8CmdBuffer[4] = u8Length;
	au8CmdBuffer[5] = 0;

	eResponse = eBL_Request(E_BL_MSG_TYPE_RAM_READ_REQUEST, 6, au8CmdBuffer, 0, NULL, &eRxType, &u8RxDataLen, pu8Buffer);
	if(eResponse != E_BL_RESPONSE_OK || eRxType != E_BL_MSG_TYPE_RAM_READ_RESPONSE)
	{
		fprintf(stderr, "%s: Response %02x", __FUNCTION__, eResponse);
		return(-1);
	}

	return(u8RxDataLen);
}

/****************************************************************************
 *
 * NAME: iBL_WriteRAM
 *
 * DESCRIPTION:
 *
 * PARAMETERS: Name        RW  Usage
 *
 * RETURNS:
 * int			0 if success
 * 				-1 if an error occured
 *
 ****************************************************************************/
static int iBL_WriteRAM(uint32_t u32Address, uint8_t u8Length, uint8_t *pu8Buffer)
{
	uint8_t u8RxDataLen = 0;
	uint8_t au8CmdBuffer[6];
	teBL_Response eResponse = 0;
	teBL_MessageType eRxType = 0;

	if(u8Length > 0xfc)
	{
		return(-1);
	}

	au8CmdBuffer[0] = (uint8_t)(u32Address >> 0) & 0xff;
	au8CmdBuffer[1] = (uint8_t)(u32Address >> 8) & 0xff;
	au8CmdBuffer[2] = (uint8_t)(u32Address >> 16) & 0xff;
	au8CmdBuffer[3] = (uint8_t)(u32Address >> 24) & 0xff;
	au8CmdBuffer[4] = u8Length;
	au8CmdBuffer[5] = 0;

	eResponse = eBL_Request(E_BL_MSG_TYPE_RAM_WRITE_REQUEST, 4, au8CmdBuffer, u8Length, pu8Buffer, &eRxType, &u8RxDataLen, pu8Buffer);
	if(eResponse != E_BL_RESPONSE_OK || eRxType != E_BL_MSG_TYPE_RAM_WRITE_RESPONSE)
	{
		fprintf(stderr, "%s: Response %02x", __FUNCTION__, eResponse);
		return(-1);
	}

	return(u8Length);
}


/****************************************************************************
 *
 * NAME: iBL_DownloadFirmwareToFlash
 *
 * DESCRIPTION:
 *  Downloads the given firmware to the module's Flash.
 *  see \ZED-TL\Sw\Source\boot.c for details
 *
 * PARAMETERS:  Name            RW  Usage
 *              pu8Firmware     R   Pointer to firmware image to download
 *              pu64Address     R   Pointer to MAC Address. If NULL, read from flash.
 *
 * RETURNS:
 * int          0 if success
 *              -1 if an error occured
 *
 ****************************************************************************/
int iBL_DownloadFirmwareToFlash(tsFW_Info *psFW_Info, int iVerify)
{
    int n;
    uint8_t u8ChunkSize;

    if (iVerbosity > 2)
    {
        printf("Text Start 0x%08x - Len %d bytes\n", psFW_Info->u32TextSectionLoadAddress, psFW_Info->u32TextSectionLength);
        printf("BSS  Start 0x%08x - Len %d bytes\n", psFW_Info->u32BssSectionLoadAddress, psFW_Info->u32BssSectionLength);
        printf("Reset entry point 0x%08x\n", ntohl(psFW_Info->u32ResetEntryPoint));
        printf("Wake entry point 0x%08x\n",  ntohl(psFW_Info->u32WakeUpEntryPoint));
    }
    
    printf("\n");
    printf("Erasing flash\n");
    
    if (iBL_EraseFlash() == -1)
    {
        fprintf(stderr, "Error erasing flash\n");
        return -1;
    }

    /* Ensure that flash is erased */
    {
        uint8_t au8Buffer1[BL_MAX_CHUNK_SIZE + 1];
        uint8_t au8Buffer2[BL_MAX_CHUNK_SIZE + 1];
        memset(au8Buffer2, 0xFF, 64);
        
        if (iBL_ReadFlash(0, 64, au8Buffer1) == -1)
        {
            printf("Error reading Flash at address 0x%08x\n", 0);
            return -1;
        }
        else
        {
            if (memcmp(au8Buffer1, au8Buffer2, 64))
            {
                printf("Flash is not blank!\n");
                return -1;
            }
            else
            {
                printf("Flash erase success\n");
            }
        }
    }
    
    printf("Writing Program to Flash\n\n");
    
    for(n = 0; n < psFW_Info->u32ImageLength;)
    {
        if((psFW_Info->u32ImageLength - n) > 128)
        {
            u8ChunkSize = 128;
        }
        else
        {
            u8ChunkSize = psFW_Info->u32ImageLength - n;
        }
        
        if(iBL_WriteFlash(n, u8ChunkSize, psFW_Info->pu8ImageData + n) == -1)
        {
            fprintf(stderr, "Failed to write at address 0x%08x", n);
            return(-1);
        }
        
        n += u8ChunkSize;
        
        printf("%c[AWriting:   %3d%%\n", 0x1B, (n * 100) / psFW_Info->u32ImageLength);
    }
    
    if (iVerify)
    {
        uint8_t au8Buffer[BL_MAX_CHUNK_SIZE + 1];
        printf("Verifying Program in Flash\n\n");

        for(n = 0; n < psFW_Info->u32ImageLength;)
        {
            if((psFW_Info->u32ImageLength - n) > 128)
            {
                u8ChunkSize = 128;
            }
            else
            {
                u8ChunkSize = psFW_Info->u32ImageLength - n;
            }
 
            if (iBL_ReadFlash(n, u8ChunkSize, au8Buffer) == -1)
            {
                fprintf(stderr, "Error reading at address 0x%08x\n", n);
                return -1;
            }
            else
            {
                if (memcmp(psFW_Info->pu8ImageData + n, au8Buffer, u8ChunkSize))
                {
                    fprintf(stderr, "Verify failed at address 0x%08x!\n", n);
                    return -1;
                }
            }
            
            n += u8ChunkSize;
            printf("%c[AVerifying: %3d%%\n", 0x1B, (n * 100) / psFW_Info->u32ImageLength);
        }
    }

    return(0);
}



/****************************************************************************
 *
 * NAME: iBL_ReadFlash
 *
 * DESCRIPTION:
 *
 * PARAMETERS: Name        RW  Usage
 *
 * RETURNS:
 * int			0 if success
 * 				-1 if an error occured
 *
 ****************************************************************************/
static int iBL_ReadFlash(uint32_t u32Address, uint8_t u8Length, uint8_t *pu8Buffer)
{
	uint8_t u8RxDataLen = 0;
	uint8_t au8CmdBuffer[6];
	teBL_Response eResponse = 0;
	teBL_MessageType eRxType = 0;

	if(u8Length > 0xfc)
	{
		return(-1);
	}

	au8CmdBuffer[0] = (uint8_t)(u32Address >> 0) & 0xff;
	au8CmdBuffer[1] = (uint8_t)(u32Address >> 8) & 0xff;
	au8CmdBuffer[2] = (uint8_t)(u32Address >> 16) & 0xff;
	au8CmdBuffer[3] = (uint8_t)(u32Address >> 24) & 0xff;
	au8CmdBuffer[4] = u8Length;
	au8CmdBuffer[5] = 0;

	eResponse = eBL_Request(E_BL_MSG_TYPE_FLASH_READ_REQUEST, 6, au8CmdBuffer, 0, NULL, &eRxType, &u8RxDataLen, pu8Buffer);
	if(eResponse != E_BL_RESPONSE_OK || eRxType != E_BL_MSG_TYPE_FLASH_READ_RESPONSE)
	{
		fprintf(stderr, "%s: Response %02x", __FUNCTION__, eResponse);
		return(-1);
	}

	return(u8RxDataLen);
}


/****************************************************************************
 *
 * NAME: iBL_EraseFlash
 *
 * DESCRIPTION:
 *
 * PARAMETERS: Name        RW  Usage
 *
 * RETURNS:
 * int          0 if success
 *              -1 if an error occured
 *
 ****************************************************************************/
static int iBL_EraseFlash(void)
{
    uint8_t u8RxDataLen = 0;
    teBL_Response eResponse = 0;
    teBL_MessageType eRxType = 0;
    uint8_t au8Buffer[64];

/*
    au8CmdBuffer[0] = (uint8_t)(u32Address >> 0) & 0xff;
    au8CmdBuffer[1] = (uint8_t)(u32Address >> 8) & 0xff;
    au8CmdBuffer[2] = (uint8_t)(u32Address >> 16) & 0xff;
    au8CmdBuffer[3] = (uint8_t)(u32Address >> 24) & 0xff;
    au8CmdBuffer[4] = u8Length;
    au8CmdBuffer[5] = 0;*/

    eResponse = eBL_Request(E_BL_MSG_TYPE_FLASH_ERASE_REQUEST, 0, NULL, 0, NULL, &eRxType, &u8RxDataLen, au8Buffer);
    if(eResponse != E_BL_RESPONSE_OK || eRxType != E_BL_MSG_TYPE_FLASH_ERASE_RESPONSE)
    {
        fprintf(stderr, "%s: Response %02x", __FUNCTION__, eResponse);
        return(-1);
    }

    return(u8RxDataLen);
}


/****************************************************************************
 *
 * NAME: iBL_WriteFlash
 *
 * DESCRIPTION:
 *
 * PARAMETERS: Name        RW  Usage
 *
 * RETURNS:
 * int          0 if success
 *              -1 if an error occured
 *
 ****************************************************************************/
static int iBL_WriteFlash(uint32_t u32Address, uint8_t u8Length, uint8_t *pu8Buffer)
{
    uint8_t u8RxDataLen = 0;
    uint8_t au8CmdBuffer[6];
    teBL_Response eResponse = 0;
    teBL_MessageType eRxType = 0;

    if(u8Length > 0xfc)
    {
        return(-1);
    }

    au8CmdBuffer[0] = (uint8_t)(u32Address >> 0) & 0xff;
    au8CmdBuffer[1] = (uint8_t)(u32Address >> 8) & 0xff;
    au8CmdBuffer[2] = (uint8_t)(u32Address >> 16) & 0xff;
    au8CmdBuffer[3] = (uint8_t)(u32Address >> 24) & 0xff;
    au8CmdBuffer[4] = u8Length;
    au8CmdBuffer[5] = 0;

    eResponse = eBL_Request(E_BL_MSG_TYPE_FLASH_PROGRAM_REQUEST, 4, au8CmdBuffer, u8Length, pu8Buffer, &eRxType, &u8RxDataLen, pu8Buffer);
    if(eResponse != E_BL_RESPONSE_OK || eRxType != E_BL_MSG_TYPE_FLASH_PROGRAM_RESPONSE)
    {
        fprintf(stderr, "%s: Response %02x", __FUNCTION__, eResponse);
        return(-1);
    }

    return(u8Length);
}



/****************************************************************************
 *
 * NAME: vJIP_DataEvent
 *
 * DESCRIPTION:
 *
 * PARAMETERS: Name        RW  Usage
 *
 * RETURNS:
 * void
 ****************************************************************************/
/****************************************************************************/
/***        Local Functions                                               ***/
/****************************************************************************/
/****************************************************************************
 *
 * NAME: eBL_Request
 *
 * DESCRIPTION:
 *
 * PARAMETERS: Name        RW  Usage
 *
 * RETURNS:
 * void
 ****************************************************************************/
static teBL_Response eBL_Request(teBL_MessageType eTxType, uint8_t u8HeaderLen, uint8_t *pu8Header, uint8_t u8TxLength, uint8_t *pu8TxData, 
                          teBL_MessageType *peRxType, uint8_t *pu8RxLength, uint8_t *pu8RxData)
{
	/* Check data is not too long */
	if(u8TxLength > 0xfd)
	{
		vDebug("\nData too long");
		return(E_BL_RESPONSE_ERROR);
	}

	/* Send message */
	if(iBL_WriteMessage(eTxType, u8HeaderLen, pu8Header, u8TxLength, pu8TxData) == -1)
	{
		return(E_BL_RESPONSE_ERROR);
	}

	/* Get the response to the request */
	return(eBL_ReadMessage(peRxType, pu8RxLength, pu8RxData));
}


/****************************************************************************
 *
 * NAME: iBL_WriteMessage
 *
 * DESCRIPTION:
 *
 * PARAMETERS: Name        RW  Usage
 *
 * RETURNS:
 * int			0 if success
 * 				-1 if an error occured
 *
 ****************************************************************************/
static int iBL_WriteMessage(teBL_MessageType eType, uint8_t u8HeaderLength, uint8_t *pu8Header, uint8_t u8Length, uint8_t *pu8Data)
{
	uint8_t u8CheckSum = 0;
	int n;

	/* total message length cannot be > 255 bytes */
	if(u8HeaderLength + u8Length >= 0xfe)
	{
		vDebug("\nLength too big");
		return(-1);
	}

	/* Send message length */
	vBL_WriteByte(u8HeaderLength + u8Length + 2, &u8CheckSum);

	/* Send message type */
	vBL_WriteByte((uint8_t)eType, &u8CheckSum);

	/* Send u8HeaderLength bytes of data */
	for(n = 0; n < u8HeaderLength; n++)
	{
		vBL_WriteByte(pu8Header[n], &u8CheckSum);
	}

	/* Send u8Length bytes of data */
	for(n = 0; n < u8Length; n++)
	{
		vBL_WriteByte(pu8Data[n], &u8CheckSum);
	}

	/* Send checksum */
	vBL_WriteByte(u8CheckSum, &u8CheckSum);

	return(0);

}


/****************************************************************************
 *
 * NAME: eBL_ReadMessage
 *
 * DESCRIPTION:
 *
 * PARAMETERS: Name        RW  Usage
 *
 * RETURNS:
 * void
 ****************************************************************************/
static teBL_Response eBL_ReadMessage(teBL_MessageType *peType, uint8_t *pu8Length, uint8_t *pu8Data)
{

	int n;
	uint8_t u8CalculatedCheckSum = 0;
	uint8_t u8ReceivedCheckSum = 0;
	uint8_t u8DummyCheckSum = 0;
	uint8_t u8Length = 0;
	teBL_Response eResponse;

	/* Get the length byte */
	if(!u8BL_ReadByte(&u8Length, &u8CalculatedCheckSum))
	{
		vDebug("Failed to get length\n");
		return(E_BL_RESPONSE_NO_RESPONSE);
	}
	
	if (iVerbosity > 10)
    {
        printf("Rx Message Length: %u\n", u8Length);
    }

	/* Check for no response */
	if(u8Length < 3)
	{
		vDebug("Length < 3\n");
		return(E_BL_RESPONSE_NO_RESPONSE);
	}

	/* Get Message type */
	if(!u8BL_ReadByte(peType, &u8CalculatedCheckSum))
	{
        vDebug("Didn't get message type\n");
		return(E_BL_RESPONSE_NO_RESPONSE);
	}

	/* Get response type */
	if(!u8BL_ReadByte(&eResponse, &u8CalculatedCheckSum))
	{
        vDebug("Didn't get response type\n");
		return(E_BL_RESPONSE_NO_RESPONSE);
	}

	/* Receive data */
	for(n = 0; n < u8Length - 3; n++)
	{
		if(!u8BL_ReadByte(&pu8Data[n], &u8CalculatedCheckSum))
		{
			vDebug("Failed to get data\n");
			return(E_BL_RESPONSE_NO_RESPONSE);
		}
	}

	/* Get the checksum byte */
	if(!u8BL_ReadByte(&u8ReceivedCheckSum, &u8DummyCheckSum))
	{
		vDebug("Failed to get checksum\n");
		return(E_BL_RESPONSE_NO_RESPONSE);
	}

	/* 02 32 30 08 1F FC 00 00 10 04 00 FF */

	/* Check data integrity */
	if(u8CalculatedCheckSum != u8ReceivedCheckSum)
	{
		vDebug("Checksum bad\n");
		return(E_BL_RESPONSE_CRC_ERROR);
	}

	*pu8Length = u8Length - 3;

	return(eResponse);

}


/****************************************************************************
 *
 * NAME: vBL_WriteByte
 *
 * DESCRIPTION:
 *
 * PARAMETERS: Name        RW  Usage
 *
 * RETURNS:
 * void
 ****************************************************************************/
static void vBL_WriteByte(uint8_t u8Data, uint8_t *pu8CheckSum)
{

	vUartWrite(BL_UART, u8Data);

	//vDebug("<W%02x>", u8Data);

	*pu8CheckSum ^= u8Data;
}


/****************************************************************************
 *
 * NAME: u8BL_ReadByte
 *
 * DESCRIPTION:
 *
 * PARAMETERS: Name        RW  Usage
 *
 * RETURNS:
 * void
 ****************************************************************************/
static uint8_t u8BL_ReadByte(uint8_t *pu8Data, uint8_t *pu8CheckSum)
{
	uint32_t u32Timeout = 50;

	while(!bUartRead(BL_UART, pu8Data))
	{
        usleep(10000);
		u32Timeout--;
		if(u32Timeout == 0)
		{
			vDebug("Timeout\n");
			return(0);
		}
	}

	*pu8CheckSum ^= *pu8Data;

	//vDebug("<R%02x>", *pu8Data);

	return(1);

}


/****************************************************************************
 *
 * NAME: pcGetName
 *
 * DESCRIPTION: Lookup name representing an ID.
 *
 * PARAMETERS: Name        RW  Usage
 *
 * RETURNS:
 * void
 ****************************************************************************/
static const char *pcGetName (tsIDNameLookup *psIDNameLookup, int iID)
{
    uint32_t i;
    for (i = 0; i < psIDNameLookup->u32Length; i++)
    {
        if (psIDNameLookup->asPairs[i].iID == iID)
        {
            return psIDNameLookup->asPairs[i].pcName;
        }
    }
    return "Unknown";
}


/****************************************************************************/
/***        END OF FILE                                                   ***/
/****************************************************************************/

