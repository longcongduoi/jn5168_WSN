
OUTPUT_FILE=$1
CHECK_DIR=$2
OPENWRTVERSION=$3
OPENWRTRELEASE=$4

try_svn() {
        [ -d ${CHECK_DIR}/.svn ] || return 1
        REV="$(cd  ${CHECK_DIR} && svn info | awk '/^Revision:/ { print $2 }')"
        REV="${REV:+r$REV}"
        [ -n "$REV" ]
}

try_svn

cat <<EOF > ${OUTPUT_FILE}
DISTRIB_ID="OpenWrt"
DISTRIB_RELEASE="${OPENWRTRELEASE}"
DISTRIB_CODENAME="${OPENWRTVERSION}"
DISTRIB_DESCRIPTION="${OPENWRTVERSION} NXP Border Router (${REV})"

EOF

