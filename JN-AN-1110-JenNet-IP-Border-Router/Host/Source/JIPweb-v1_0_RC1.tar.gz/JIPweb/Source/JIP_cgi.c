/****************************************************************************
 *
 * MODULE:             JIP Web Apps
 *
 * COMPONENT:          JIP cgi program
 *
 * REVISION:           $Revision: 50008 $
 *
 * DATED:              $Date: 2012-11-30 09:46:09 +0000 (Fri, 30 Nov 2012) $
 *
 * AUTHOR:             Matt Redfearn
 *
 ****************************************************************************
 *
 * This software is owned by NXP B.V. and/or its supplier and is protected
 * under applicable copyright laws. All rights are reserved. We grant You,
 * and any third parties, a license to use this software solely and
 * exclusively on NXP products [NXP Microcontrollers such as JN5148, JN5142, JN5139]. 
 * You, and any third parties must reproduce the copyright and warranty notice
 * and any other legend of ownership on each copy or partial copy of the 
 * software.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.

 * Copyright NXP B.V. 2012. All rights reserved
 *
 ***************************************************************************/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <arpa/inet.h>
#include <netdb.h>
#include <errno.h>
#include <sys/stat.h>
#include <unistd.h>
#include <time.h>

#include <json.h>

#include <Zeroconf.h> 
#include <JIP.h>

#include "CGI.h"

#define DISPLAY_JENNET_MIB


#define CACHE_DEFINITIONS_FILE_NAME "/tmp/jip_cache_definitions.xml"
#define CACHE_NETWORK_FILE_NAME "/tmp/jip_cache_network.xml"


static int verbosity = 0;

#ifndef VERSION
#error Version is not defined!
#else
const char *Version = "0.1 (r" VERSION ")";
#endif

static tsJIP_Context sJIP_Context;

static tsCGI sCGI;


int main(int argc, char *argv[])
{
    char *pcAction                          = NULL;
    char *pcBRNAddress                      = NULL;
    char *pcNodeAddress                     = NULL;
    char *pcMulticastAddress                = NULL;
    char *pcMibId                           = NULL;
    char *pcVarIndex                        = NULL;
    char *pcRefreshNodes                    = NULL;
    char *pcUpdateValue                     = NULL;
    teJIP_Status eStatus;
    
    struct json_object* psJsonResult        = NULL;
    struct json_object* psJsonNetwork       = NULL;
    
    struct json_object* psJsonStatus        = NULL;
    struct json_object* psJsonStatusInt     = NULL;
    struct json_object* psJsonStatusText    = NULL;
    
#define SET_STATUS(i, t) \
        psJsonStatusInt     = json_object_new_int(i); \
        psJsonStatusText    = json_object_new_string(t); \

#define EXIT_STATUS(i, t) \
        SET_STATUS(i, t)  \
        goto end;
        
    psJsonResult = json_object_new_object();
    psJsonStatus = json_object_new_object();    

    
    if (eCGIReadVariables(&sCGI) != E_CGI_OK)
    {
        printf("Error initialising CGI\n\r");
        return -1;
    }
    
    printf("Content-type: application/json\r\n\r\n");
    
    pcAction = pcCGIGetValue(&sCGI, "action");
    if (!pcAction)
    {
        EXIT_STATUS(E_CGI_ERROR, "Unknown Request");
    }

    pcBRNAddress        = pcCGIGetValue(&sCGI, "BRaddress");
    pcNodeAddress       = pcCGIGetValue(&sCGI, "nodeaddress");
    pcMibId             = pcCGIGetValue(&sCGI, "mib");
    pcVarIndex          = pcCGIGetValue(&sCGI, "var");
    pcRefreshNodes      = pcCGIGetValue(&sCGI, "refresh");
    pcUpdateValue       = pcCGIGetValue(&sCGI, "value");
    
    if (pcRefreshNodes == NULL)
    {
        pcRefreshNodes = "yes";
    }
    
    if (strcmp(pcAction, "getVersion") == 0)
    {
        struct json_object* psJsonVersionList;
        struct json_object* psJsonCGIVersion;
        struct json_object* psJsonLibVersion;
        
        psJsonVersionList = json_object_new_object();
        
        json_object_object_add (psJsonResult,
                                "Version",
                                psJsonVersionList);

         psJsonCGIVersion = json_object_new_string(Version);
         psJsonLibVersion = json_object_new_string(JIP_Version);
 
         json_object_object_add (psJsonVersionList,
                                 "JIPcgi",
                                 psJsonCGIVersion);
 
         json_object_object_add (psJsonVersionList,
                                 "libJIP",
                                 psJsonLibVersion);
        
        EXIT_STATUS(E_CGI_OK, "Success");
    }
    else if (strcmp(pcAction, "discoverBRs") == 0)
    {
        int iNumAddresses;
        struct in6_addr *asAddresses;
        if (ZC_Get_Module_Addresses(&asAddresses, &iNumAddresses) != 0)
        {
            EXIT_STATUS(E_CGI_ERROR, "Failed to find gateway address via Zeroconf");
        }
        else
        {
            struct json_object* psJsonBRList;
            int i;
            
            psJsonBRList = json_object_new_array();
            
            for (i = 0; i < iNumAddresses; i++)
            {
                struct json_object* psJsonBRAddress;
                char buffer[INET6_ADDRSTRLEN] = "Could not determine address\n";
                inet_ntop(AF_INET6, &asAddresses[i], buffer, INET6_ADDRSTRLEN);
                
                psJsonBRAddress = json_object_new_string(buffer);
                
                json_object_array_add(psJsonBRList, psJsonBRAddress);
            }
                
            json_object_object_add (psJsonResult,
                                    "BRList",
                                    psJsonBRList);

            free(asAddresses);
            EXIT_STATUS(E_CGI_OK, "Success");
        }
    }

    if (pcBRNAddress == NULL)
    {
        EXIT_STATUS(E_CGI_ERROR, "No BR Specified");
    }

    if (eStatus = eJIP_Init(&sJIP_Context) != E_JIP_OK)
    {
        EXIT_STATUS(eStatus, "JIP startup failed");
    }

    if (eStatus = eJIP_Connect(&sJIP_Context, pcBRNAddress, JIP_DEFAULT_PORT) != E_JIP_OK)
    {
        EXIT_STATUS(eStatus, "JIP connect failed");
    }
    
    /* Load the cached device id's and any network contents if possible */
    if (eJIPService_PersistXMLLoadDefinitions(&sJIP_Context, CACHE_DEFINITIONS_FILE_NAME) != E_JIP_OK)
    {
        // Couldn't load the definitions file, fall back to discovery.
        if (eJIPService_DiscoverNetwork(&sJIP_Context) != E_JIP_OK)
        {
            //printf("JIP discover network failed\n");
        }
    }
    else
    {
        if (strcmp(pcRefreshNodes, "yes") == 0)
        {
            if (eStatus = eJIPService_DiscoverNetwork(&sJIP_Context) != E_JIP_OK)
            {
                EXIT_STATUS(eStatus, "JIP discover network failed");
            }
        }
        else
        {
            /* Load the cached network if possible */
            if (eJIPService_PersistXMLLoadNetwork(&sJIP_Context, CACHE_NETWORK_FILE_NAME) != E_JIP_OK)
            {
                // Couldn't load the network file, fall back to discovery.
                if (eJIPService_DiscoverNetwork(&sJIP_Context) != E_JIP_OK)
                {
                    //printf("JIP discover network failed\n");
                }
            }
        }
    }
    
    if (strcmp(pcAction, "discover") == 0)
    {
        struct json_object* psJsonNodeList;
        
        psJsonNetwork = json_object_new_object();
        psJsonNodeList = json_object_new_array();
        
        {
            tsNode *psNode;
            tsMib *psMib;
            tsVar *psVar;
            uint32_t NodeIndex, MibIndex, VarIndex;
            
            eJIP_Lock(&sJIP_Context);
            
            psNode = sJIP_Context.sNetwork.psNodes;
            //for (NodeIndex = 0; NodeIndex < sJIP_Context.sNetwork.u32NumNodes; NodeIndex++)
            while (psNode)
            {
                struct json_object* psJsonNode;
                struct json_object* psJsonNodeAddress;
                struct json_object* psJsonNodeDeviceId;
                struct json_object* psJsonMibList;

                char buffer[INET6_ADDRSTRLEN] = "Could not determine address\n";
                inet_ntop(AF_INET6, &psNode->sNode_Address.sin6_addr, buffer, INET6_ADDRSTRLEN);
                
                psJsonNode = json_object_new_object();
                psJsonNodeAddress = json_object_new_string(buffer);
                
                json_object_object_add (psJsonNode,
                                "IPv6Address",
                                psJsonNodeAddress);
                
                psJsonNodeDeviceId = json_object_new_int(psNode->u32DeviceId);
                json_object_object_add (psJsonNode,
                                "DeviceID",
                                psJsonNodeDeviceId);
                
                json_object_array_add(psJsonNodeList, psJsonNode);
                
                psJsonMibList = json_object_new_array();
                json_object_object_add (psJsonNode,
                                "MiBs",
                                psJsonMibList);


                psMib = psNode->psMibs;
                while (psMib)
                {
                    struct json_object* psJsonMib;
                    struct json_object* psJsonMibId;
                    struct json_object* psJsonMibName;
                    struct json_object* psJsonVarList;

                    psJsonMib = json_object_new_object();
                    psJsonMibId =   json_object_new_int(psMib->u32MibId);
                    psJsonMibName = json_object_new_string(psMib->pcName);
                    
                    json_object_object_add (psJsonMib,
                                    "ID",
                                    psJsonMibId);
                    
                    json_object_object_add (psJsonMib,
                                    "Name",
                                    psJsonMibName);
                    
                    json_object_array_add(psJsonMibList, psJsonMib);
                    
                    psJsonVarList = json_object_new_array();
                    json_object_object_add (psJsonMib,
                                    "Vars",
                                    psJsonVarList);

                    psVar = psMib->psVars;
                    while (psVar)
                    {
                        struct json_object* psJsonVar;
                        struct json_object* psJsonVarName;
                        struct json_object* psJsonVarIndex;
                        struct json_object* psJsonVarType;
                        struct json_object* psJsonVarAccessType;
                        struct json_object* psJsonVarSecurity;

                        psJsonVar = json_object_new_object();
                        
                        psJsonVarName = json_object_new_string(psVar->pcName);
                        json_object_object_add (psJsonVar,
                                        "Name",
                                        psJsonVarName);

                        psJsonVarIndex = json_object_new_int(psVar->u8Index);
                        json_object_object_add (psJsonVar,
                                        "Index",
                                        psJsonVarIndex);
                        
                        psJsonVarType = json_object_new_int(psVar->eVarType);
                        json_object_object_add (psJsonVar,
                                        "Type",
                                        psJsonVarType);
                        
                        psJsonVarAccessType = json_object_new_int(psVar->eAccessType);
                        json_object_object_add (psJsonVar,
                                        "AccessType",
                                        psJsonVarAccessType);
                        
                        psJsonVarSecurity = json_object_new_int(psVar->eSecurity);
                        json_object_object_add (psJsonVar,
                                        "Security",
                                        psJsonVarSecurity);
                        
                        json_object_array_add(psJsonVarList, psJsonVar);
                        psVar = psVar->psNext;
                    }
                    psMib = psMib->psNext;
                }
                psNode = psNode->psNext;
            }
            
            eJIP_Unlock(&sJIP_Context);
        }
        
        json_object_object_add (psJsonNetwork,
                                "Nodes",
                                psJsonNodeList);
        
        SET_STATUS(E_CGI_OK, "Success");
    }
    else if (strcmp(pcAction, "GetVar") == 0)
    {
        struct json_object* psJsonNodeList;
        
        psJsonNetwork = json_object_new_object();
        psJsonNodeList = json_object_new_array();
        
        if (pcNodeAddress && pcMibId && pcVarIndex)
        {
            tsNode *psNode;
            tsMib *psMib;
            tsVar *psVar;

            eJIP_Lock(&sJIP_Context);
            
            psNode = sJIP_Context.sNetwork.psNodes;
            while (psNode)
            {
                char buffer[INET6_ADDRSTRLEN] = "Could not determine address\n";
                inet_ntop(AF_INET6, &psNode->sNode_Address.sin6_addr, buffer, INET6_ADDRSTRLEN);
                
                if (strcmp(pcNodeAddress, buffer) == 0)
                {
                    psMib = psJIP_LookupMib(psNode, NULL, pcMibId);
                    
                    if (psMib)
                    {              
                        psVar = psJIP_LookupVar(psMib, NULL, pcVarIndex);
                
                        if (psVar)
                        {
                            struct json_object* psJsonNode;
                            struct json_object* psJsonNodeAddress;
                            struct json_object* psJsonMibList;
                            
                            struct json_object* psJsonMib;
                            struct json_object* psJsonMibName;
                            struct json_object* psJsonVarList;

                            struct json_object* psJsonVar;
                            struct json_object* psJsonVarName;
                            struct json_object* psJsonVarValue;
                            
                            char *acCurrentValue = malloc(255);
                            uint32_t u32CurrentValueLength = 255;

                            psJsonNode = json_object_new_object();
                            psJsonNodeAddress = json_object_new_string(buffer);

                            json_object_object_add (psJsonNode,
                                            "IPv6Address",
                                            psJsonNodeAddress);
                            
                            json_object_array_add(psJsonNodeList, psJsonNode);
                            
                            psJsonMibList = json_object_new_array();
                            json_object_object_add (psJsonNode,
                                            "MiBs",
                                            psJsonMibList);
                            
                            psJsonMib = json_object_new_object();
                            psJsonMibName = json_object_new_string(psMib->pcName);
                            
                            json_object_object_add (psJsonMib,
                                            "Name",
                                            psJsonMibName);
                            
                            json_object_array_add(psJsonMibList, psJsonMib);
                            
                            psJsonVarList = json_object_new_array();
                            json_object_object_add (psJsonMib,
                                            "Vars",
                                            psJsonVarList);

                            psJsonVar = json_object_new_object();
                            psJsonVarName = json_object_new_string(psVar->pcName);
                            
                            json_object_object_add (psJsonVar,
                                            "Name",
                                            psJsonVarName);

                            eStatus = eJIP_GetVar(&sJIP_Context, psVar);
                            
                            if ((eStatus == E_JIP_OK) && psVar->pvData)
                            {
                                switch (psVar->eVarType)
                                {
#define TEST(a, b, c) case  (a): sprintf(acCurrentValue, b, *((c*)psVar->pvData)); break
                                    TEST(E_JIP_VAR_TYPE_INT8,  "%d",   uint8_t);
                                    TEST(E_JIP_VAR_TYPE_UINT8, "%u",   uint8_t);
                                    TEST(E_JIP_VAR_TYPE_INT16, "%d",   uint16_t);
                                    TEST(E_JIP_VAR_TYPE_UINT16,"%u",   uint16_t);
                                    TEST(E_JIP_VAR_TYPE_INT32, "%d",   uint32_t);
                                    TEST(E_JIP_VAR_TYPE_UINT32,"%u",   uint32_t);
                                    TEST(E_JIP_VAR_TYPE_INT64, "%llx", uint64_t);
                                    TEST(E_JIP_VAR_TYPE_UINT64,"%llx", uint64_t);
                                    TEST(E_JIP_VAR_TYPE_FLT,   "%f",   float);
                                    TEST(E_JIP_VAR_TYPE_DBL,   "%f",   double);
                                    case  (E_JIP_VAR_TYPE_STR): 
                                        sprintf(acCurrentValue, "%s",   ((uint8_t*)psVar->pvData)); 
                                        break;
                                    case (E_JIP_VAR_TYPE_BLOB):
                                    {
                                        uint32_t i, u32Position;
                                        u32Position += sprintf(acCurrentValue, "0x");
                                        for (i = 0; i < psVar->u8Size; i++)
                                        {
                                            sprintf(&acCurrentValue[u32Position], "%02x", ((uint8_t*)psVar->pvData)[i]);
                                        }
                                        break;
                                    }
                                    case (E_JIP_VAR_TYPE_TABLE_BLOB):
                                    {
                                        tsTable *psTable;
                                        tsTableRow *psTableRow;
                                        psTable = (tsTable *)psVar->pvData;
                                        uint32_t u32CurrentValuePos = 0;
                                        int i;

                                        if (psTable->u32NumRows > 0)
                                        {

                                            for (i = 0; i < psTable->u32NumRows; i++)
                                            {
                                                psTableRow = &psTable->psRows[i];
                                                if (psTableRow->pvData)
                                                {
                                                    uint32_t j;
                                                    uint8_t *pcNewCurrentValue;
                                                    
                                                    pcNewCurrentValue = realloc(acCurrentValue, u32CurrentValueLength + psTableRow->u32Length);
                                                    
                                                    if (!pcNewCurrentValue)
                                                    {
                                                        printf("Failed to print Table\n");
                                                        break;
                                                    }
                                                    
                                                    acCurrentValue = pcNewCurrentValue;
                                                    u32CurrentValueLength += psTableRow->u32Length;

                                                    u32CurrentValuePos += sprintf(&acCurrentValue[u32CurrentValuePos], "<P style=\"margin-left: 50px; \"> %03d { 0x", i);
                                                    for (j = 0; j < psTableRow->u32Length; j++)
                                                    {
                                                        u32CurrentValuePos += sprintf(&acCurrentValue[u32CurrentValuePos], "%02x", ((uint8_t*)psTableRow->pvData)[j]);
                                                    }
                                                    u32CurrentValuePos += sprintf(&acCurrentValue[u32CurrentValuePos], " }</P>\n");
                                                }
                                                else
                                                {
                                                    u32CurrentValuePos += sprintf(&acCurrentValue[u32CurrentValuePos], "<P style=\"margin-left: 50px; \"> %03d { Empty Row }</P>\n", i);
                                                }
                                            }
                                        }
                                        else
                                        {
                                            sprintf(acCurrentValue, "Empty table");
                                        }
                                        break;
                                    }
                                    default: sprintf(acCurrentValue, "Unknown Type");
#undef TEST
                                }
                                psJsonVarValue = json_object_new_string(acCurrentValue);
                            
                                json_object_object_add (psJsonVar,
                                            "Value",
                                            psJsonVarValue);
                                SET_STATUS(E_CGI_OK, "Success");
                            }
                            else
                            {
                                sprintf(acCurrentValue, "?");
                                psJsonVarValue = json_object_new_string(acCurrentValue);
                            
                                json_object_object_add (psJsonVar,
                                            "Value",
                                            psJsonVarValue);
                                
                                switch (eStatus)
                                {
                                    case (E_JIP_ERROR_WOULD_BLOCK):     SET_STATUS(eStatus, "Would block"); break;
                                    case (E_JIP_ERROR_NO_MEM):          SET_STATUS(eStatus, "Memory allocation failure"); break;
                                    case (E_JIP_ERROR_TIMEOUT):         SET_STATUS(eStatus, "Timed out"); break;
                                    case (E_JIP_ERROR_BAD_MIB_INDEX):   SET_STATUS(eStatus, "Bad Mib Index / ID"); break;
                                    case (E_JIP_ERROR_BAD_VAR_INDEX):   SET_STATUS(eStatus, "Bad Var index"); break;
                                    case (E_JIP_ERROR_NO_ACCESS):       SET_STATUS(eStatus, "Access failure"); break;
                                    case (E_JIP_ERROR_BAD_BUFFER_SIZE): SET_STATUS(eStatus, "Bad buffer size"); break;
                                    case (E_JIP_ERROR_WRONG_TYPE):      SET_STATUS(eStatus, "Wrong Type"); break;
                                    case (E_JIP_ERROR_BAD_VALUE):       SET_STATUS(eStatus, "Bad value"); break;
                                    case (E_JIP_ERROR_DISABLED):        SET_STATUS(eStatus, "Variable disabled"); break;
                                    case (E_JIP_ERROR_FAILED):      
                                    default:
                                                                        SET_STATUS(eStatus, "Failed"); break;
                                }
                            }
                            json_object_array_add(psJsonVarList, psJsonVar);
                        }
                    }
                }
            
                psNode = psNode->psNext;
            }
            eJIP_Unlock(&sJIP_Context);
        }
        
        json_object_object_add (psJsonNetwork,
                                "Nodes",
                                psJsonNodeList);
    }
    else if (strcmp(pcAction, "SetVar") == 0)
    {
        struct json_object* psJsonNodeList;
        
        psJsonNetwork = json_object_new_object();
        psJsonNodeList = json_object_new_array();
        
        if ((strncmp(pcNodeAddress, "ff", 2) == 0) || (strncmp(pcNodeAddress, "FF", 2) == 0))
        {
            // Check for multicast set.
            pcMulticastAddress = pcNodeAddress;
        }
        
        if (pcNodeAddress && pcMibId && pcVarIndex)
        {
            tsNode *psNode;
            tsMib *psMib;
            tsVar *psVar;

            eJIP_Lock(&sJIP_Context);
            
            psNode = sJIP_Context.sNetwork.psNodes;
            while (psNode)
            {
                char buffer[INET6_ADDRSTRLEN] = "Could not determine address\n";
                inet_ntop(AF_INET6, &psNode->sNode_Address.sin6_addr, buffer, INET6_ADDRSTRLEN);
                
                if ((strcmp(pcNodeAddress, buffer) == 0) || (pcMulticastAddress))
                {
                    psMib = psJIP_LookupMib(psNode, NULL, pcMibId);
                    
                    if (psMib)
                    {              
                        psVar = psJIP_LookupVar(psMib, NULL, pcVarIndex);

                        if (psVar)
                        {
                            char *buf = NULL;
                            int supported = 1, freeable = 1;
                            uint32_t u32Size = 0;
                            
                            switch (psVar->eVarType)
                            {
                                case (E_JIP_VAR_TYPE_INT8):
                                case (E_JIP_VAR_TYPE_UINT8):
                                    buf = malloc(sizeof(uint8_t));
                                    errno = 0;
                                    buf[0] = strtoul(pcUpdateValue, NULL, 0);
                                    if (errno)
                                    {
                                        SET_STATUS(E_CGI_ERROR, "Invalid value for datatype");
                                        supported = 0;
                                        break;
                                        //printf("Invalid value: '%s'\n\r", pcUpdateValue);
                                        //return 0;
                                    }
                                    break;
                                
                                case (E_JIP_VAR_TYPE_INT16):
                                case (E_JIP_VAR_TYPE_UINT16):
                                {
                                    uint16_t u16Var;
                                    errno = 0;
                                    u16Var = strtoul(pcUpdateValue, NULL, 0);
                                    if (errno)
                                    {
                                        SET_STATUS(E_CGI_ERROR, "Invalid value for datatype");
                                        supported = 0;
                                        break;
                                        //printf("Invalid value: '%s'\n\r", pcUpdateValue);
                                        //return 0;
                                    }
                                    buf = malloc(sizeof(uint16_t));
                                    memcpy(buf, &u16Var, sizeof(uint16_t));
                                    break;
                                }
                                    
                                case (E_JIP_VAR_TYPE_INT32):
                                case (E_JIP_VAR_TYPE_UINT32):
                                {
                                    uint32_t u32Var;
                                    errno = 0;
                                    u32Var = strtoul(pcUpdateValue, NULL, 0);
                                    if (errno)
                                    {
                                        SET_STATUS(E_CGI_ERROR, "Invalid value for datatype");
                                        supported = 0;
                                        break;
                                        //printf("Invalid value: '%s'\n\r", pcUpdateValue);
                                        //return 0;
                                    }
                                    buf = malloc(sizeof(uint32_t));
                                    memcpy(buf, &u32Var, sizeof(uint32_t));
                                    break;
                                }
                                
                                case (E_JIP_VAR_TYPE_INT64):
                                case (E_JIP_VAR_TYPE_UINT64):
                                {
                                    uint64_t u64Var;
                                    errno = 0;
                                    u64Var = strtoull(pcUpdateValue, NULL, 0);
                                    if (errno)
                                    {
                                        SET_STATUS(E_CGI_ERROR, "Invalid value for datatype");
                                        supported = 0;
                                        break;
                                        //printf("Invalid value: '%s'\n\r", pcUpdateValue);
                                        //return 0;
                                    }
                                    buf = malloc(sizeof(uint64_t));
                                    memcpy(buf, &u64Var, sizeof(uint64_t));
                                    break;
                                }
                                
                                case (E_JIP_VAR_TYPE_FLT):
                                {
                                    float f32Var = strtof(pcUpdateValue, NULL);
                                    buf = malloc(sizeof(uint32_t));
                                    memcpy(buf, &f32Var, sizeof(uint32_t));
                                    break;
                                }
                                
                                case (E_JIP_VAR_TYPE_DBL):
                                {
                                    double d64Var = strtod(pcUpdateValue, NULL);
                                    buf = malloc(sizeof(uint64_t));
                                    memcpy(buf, &d64Var, sizeof(uint64_t));
                                    break;
                                }
                                    
                                case(E_JIP_VAR_TYPE_STR):
                                {
                                    buf = pcUpdateValue;
                                    //printf("Update to \"%s\"\n", buf);
                                    u32Size = strlen(pcUpdateValue);
                                    freeable = 0;
                                    break;
                                }
                                    
                                case(E_JIP_VAR_TYPE_BLOB):
                                {
                                    int i, j;
                                    buf = malloc(strlen(pcUpdateValue));
                                    memset(buf, 0, strlen(pcUpdateValue));
                                    if (strncmp(pcUpdateValue, "0x", 2) == 0)
                                    {
                                        pcUpdateValue += 2;
                                    }
                                    u32Size = 0;
                                    for (i = 0, j = 0; (i < strlen(pcUpdateValue)) && supported; i++)
                                    {
                                        uint8_t u8Nibble = 0;
                                        if ((pcUpdateValue[i] >= '0') && (pcUpdateValue[i] <= '9'))
                                        {
                                            u8Nibble = pcUpdateValue[i]-'0';
                                            //printf("Got 0-9 0x%02x\n", );
                                        }
                                        else if ((pcUpdateValue[i] >= 'a') && (pcUpdateValue[i] <= 'f'))
                                        {
                                            u8Nibble = pcUpdateValue[i]-'a' + 0x0A;
                                        }
                                        else if ((pcUpdateValue[i] >= 'A') && (pcUpdateValue[i] <= 'F'))
                                        {
                                            u8Nibble = pcUpdateValue[i]-'A' + 0x0A;
                                        }
                                        else
                                        {
                                            //printf("String contains non-hex character\n");
                                            supported = 0;
                                            break;
                                        }
                                            
                                        if ((u32Size & 0x01) == 0)
                                        {
                                            // Even numbered byte
                                            buf[j] = u8Nibble << 4;
                                        }
                                        else
                                        {
                                            buf[j] |= u8Nibble & 0x0F;
                                            j++;
                                        }
                                        u32Size++;
                                    }
                                    if (u32Size & 0x01)
                                    {
                                        // Odd length string
                                        u32Size = (u32Size >> 1) + 1;
                                    }
                                    else
                                    {
                                        u32Size = u32Size >> 1;
                                    }
                                    
                                    break;
                                }
                                
                                default:
                                    supported = 0;
                            }
                            
                            if (supported)
                            {
                                if (pcMulticastAddress)
                                {
                                    tsJIPAddress MCastAddress;
                                    int s;
                                    
                                    memset (&MCastAddress, 0, sizeof(struct sockaddr_in6));
                                    MCastAddress.sin6_family  = AF_INET6;
                                    MCastAddress.sin6_port    = htons(1873);
                                    
                                    s = inet_pton(AF_INET6, pcMulticastAddress, &MCastAddress.sin6_addr);
                                    if (s <= 0)
                                    {
                                        if (s == 0)
                                        {
                                            EXIT_STATUS(E_CGI_ERROR, "Unknown host");
                                        }
                                        else if (s < 0)
                                        {
                                            EXIT_STATUS(E_CGI_ERROR, "inet_pton failed");
                                        }
                                    }
                                    
                                    if (eJIP_MulticastSetVar(&sJIP_Context, psVar, buf, u32Size, &MCastAddress, 2) != E_JIP_OK)
                                    {
                                        SET_STATUS(E_CGI_ERROR, "Error setting new value");
                                    }
                                    else
                                    {
                                        SET_STATUS(E_CGI_OK, "Success");
                                    }
                                }
                                else
                                {
                                    if (eStatus = eJIP_SetVar(&sJIP_Context, psVar, buf, u32Size) != E_JIP_OK)
                                    {
                                        switch (eStatus)
                                        {
                                            case (E_JIP_ERROR_WOULD_BLOCK):     SET_STATUS(eStatus, "Would block"); break;
                                            case (E_JIP_ERROR_NO_MEM):          SET_STATUS(eStatus, "Memory allocation failure"); break;
                                            case (E_JIP_ERROR_TIMEOUT):         SET_STATUS(eStatus, "Timed out"); break;
                                            case (E_JIP_ERROR_BAD_MIB_INDEX):   SET_STATUS(eStatus, "Bad Mib Index / ID"); break;
                                            case (E_JIP_ERROR_BAD_VAR_INDEX):   SET_STATUS(eStatus, "Bad Var index"); break;
                                            case (E_JIP_ERROR_NO_ACCESS):       SET_STATUS(eStatus, "Access failure"); break;
                                            case (E_JIP_ERROR_BAD_BUFFER_SIZE): SET_STATUS(eStatus, "Bad buffer size"); break;
                                            case (E_JIP_ERROR_WRONG_TYPE):      SET_STATUS(eStatus, "Wrong Type"); break;
                                            case (E_JIP_ERROR_BAD_VALUE):       SET_STATUS(eStatus, "Bad value"); break;
                                            case (E_JIP_ERROR_DISABLED):        SET_STATUS(eStatus, "Variable disabled"); break;
                                            case (E_JIP_ERROR_FAILED):      
                                            default:
                                                                                SET_STATUS(eStatus, "Failed"); break;
                                        }
                                    }
                                    else
                                    {
                                        SET_STATUS(E_CGI_OK, "Success");
                                    }
                                }
                            }
                            else
                            {
                                SET_STATUS(eStatus, "Variable type not supported");
                            }
                            
                            if (freeable)
                            {
                                free(buf);
                            }
                            goto updated;
                        }
                    }
                }
            
                psNode = psNode->psNext;
            }
            
            SET_STATUS(E_JIP_ERROR_FAILED, "Node not found");
            
updated:
            eJIP_Unlock(&sJIP_Context);
        }
    }
    else
    {
        SET_STATUS(E_JIP_ERROR_FAILED, "Unknown action");
    }

    (void)eJIPService_PersistXMLSaveDefinitions(&sJIP_Context, CACHE_DEFINITIONS_FILE_NAME);
    (void)eJIPService_PersistXMLSaveNetwork(&sJIP_Context, CACHE_NETWORK_FILE_NAME);

end:
    json_object_object_add (psJsonResult,
                            "Status",
                            psJsonStatus);

    json_object_object_add (psJsonStatus,
                            "Value",
                            psJsonStatusInt);
    
    json_object_object_add (psJsonStatus,
                            "Description",
                            psJsonStatusText);
    
    if (psJsonNetwork)
    {
        json_object_object_add (psJsonResult,
                                "Network",
                                psJsonNetwork);
    }
    
    printf(json_object_to_json_string(psJsonResult));

    return 0;
}
